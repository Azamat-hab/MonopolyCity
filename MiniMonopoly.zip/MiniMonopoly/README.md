# Мини-Монополия

## Онлайн (Firebase) — один раз настроить
1. console.firebase.google.com → ваш проект → Build → Firestore Database → Create database → Start in test mode.
2. Вкладка Rules, вставьте и нажмите Publish (чтобы не истекло через 30 дней):
   rules_version = '2';
   service cloud.firestore { match /databases/{db}/documents { match /{document=**} { allow read, write: if true; } } }
3. Project settings (шестерёнка) → Your apps → Add app → Android. Package name: com.example.minimonopoly
4. Скачайте google-services.json и положите в корень репозитория GitHub рядом с MiniMonopoly.zip.
   (Для Android Studio: в папку app/.)
Авторизация не нужна.

## Bluetooth
Сначала свяжите телефоны в настройках Bluetooth Android. Один создаёт игру, остальные подключаются из списка.
