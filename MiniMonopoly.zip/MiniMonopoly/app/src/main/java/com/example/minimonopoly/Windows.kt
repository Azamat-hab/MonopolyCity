package com.example.minimonopoly

import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

val INK = Color(0xFF1B2A41)
val CREAM = Color(0xFFFFF3E0)

/** Область поверх картинки: координаты в пикселях исходной текстуры, s = dp на пиксель. */
@Composable
fun Area(
    s: Dp, x1: Int, y1: Int, x2: Int, y2: Int,
    onClick: (() -> Unit)? = null,
    align: Alignment = Alignment.Center,
    content: @Composable BoxScope.() -> Unit = {}
) {
    var m = Modifier.offset(s * x1, s * y1).size(s * (x2 - x1), s * (y2 - y1))
    if (onClick != null) m = m.clickable(onClick = onClick)
    Box(m, contentAlignment = align, content = content)
}

@Composable
fun Dim(radius: Dp = 20.dp) {
    Box(Modifier.fillMaxSize().background(Color(0xAA101020), RoundedCornerShape(radius)))
}

@Composable
fun WinDialog(
    onClose: () -> Unit, res: Int, imgW: Int, imgH: Int,
    below: @Composable () -> Unit = {},
    content: @Composable BoxScope.(Dp) -> Unit
) {
    val maxH = LocalConfiguration.current.screenHeightDp.dp * 0.86f
    val w = minOf(360.dp, maxH * imgW / imgH)
    val s = w / imgW
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(w, s * imgH)) {
                Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                content(this, s)
            }
            below()
        }
    }
}

@Composable
fun CreamDialog(
    title: String, onClose: () -> Unit,
    confirm: @Composable () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = CREAM, titleContentColor = INK, textContentColor = INK,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp), content = content
            )
        },
        confirmButton = confirm,
        dismissButton = { TextButton(onClick = onClose) { Text("Закрыть") } }
    )
}

// ---------------- Свободная точка ----------------
@Composable
fun SpotWindow(game: Game, spot: Int, onClose: () -> Unit) {
    val ok = game.canAct
    WinDialog(
        onClose, R.drawable.win_spot, 466, 444,
        below = { if (!ok) Text("Строить можно только в свой ход", color = Color.White, fontSize = 12.sp) }
    ) { s ->
        listOf(BType.STALL to 85, BType.SHOP to 192, BType.FLAT to 295).forEach { (t, y) ->
            val can = ok && game.viewer.money >= t.cost
            val click: (() -> Unit)? =
                if (can) ({ game.act(Act("build", spot, 0, t.name)); onClose() }) else null
            Area(s, 30, y, 433, y + 85, click) { if (!can) Dim() }
        }
        Area(s, 140, 385, 325, 432, onClose)
        Area(s, 418, 20, 460, 62, onClose)
    }
}

// ---------------- Аватар ----------------
val AVATAR_COLORS = listOf(0xFF42A5F5, 0xFFEF5350, 0xFF66BB6A, 0xFFFFA726, 0xFFAB47BC, 0xFF26C6DA)

@Composable
fun Avatar(name: String, idx: Int, size: Dp) {
    Box(
        Modifier.size(size).background(Color(AVATAR_COLORS[idx % AVATAR_COLORS.size]), RoundedCornerShape(size / 5)),
        contentAlignment = Alignment.Center
    ) {
        Text(name.trim().take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = (size.value * 0.55f).sp)
    }
}

// ---------------- Профиль ----------------
@Composable
fun ProfileWindow(name: String, avatar: Int, onSave: (String, Int) -> Unit, onClose: () -> Unit) {
    var text by remember { mutableStateOf(name) }
    var av by remember { mutableIntStateOf(avatar) }
    WinDialog(
        onClose, R.drawable.win_profile, 463, 348,
        below = { Text("Нажмите на аватар, чтобы сменить цвет", color = Color.White, fontSize = 11.sp) }
    ) { s ->
        Area(s, 33, 90, 173, 245, { av = (av + 1) % AVATAR_COLORS.size }) {
            Avatar(text.ifBlank { "?" }, av, s * 130)
        }
        Area(s, 203, 146, 358, 186, align = Alignment.CenterStart) {
            BasicTextField(
                value = text, onValueChange = { text = it.take(14).replace("|", "") },
                singleLine = true,
                textStyle = TextStyle(fontSize = (s.value * 30).sp, color = INK, fontWeight = FontWeight.Bold)
            )
        }
        Area(s, 106, 265, 356, 322, { onSave(text.ifBlank { "Игрок 1" }, av) })
        Area(s, 414, 22, 456, 64, onClose)
    }
}

// ---------------- Рейтинг ----------------
@Composable
fun RatingWindow(game: Game, onClose: () -> Unit) {
    val sorted = game.players.sortedByDescending { game.netWorth(it) }
    WinDialog(
        onClose, R.drawable.win_rating, 678, 410,
        below = {
            sorted.drop(3).forEachIndexed { i, p ->
                Text("${i + 4}. ${p.name}: ${fmt(game.netWorth(p))} \$", color = Color.White, fontSize = 13.sp)
            }
        }
    ) { s ->
        val rows = listOf(118, 165, 213)
        sorted.take(3).forEachIndexed { i, p ->
            val y = rows[i]
            val w = game.netWorth(p)
            val diff = w - Config.START_MONEY
            Area(s, 122, y + 10, 148, y + 36) { Box(Modifier.fillMaxSize().background(p.color, CircleShape)) }
            Area(s, 160, y, 340, y + 44, align = Alignment.CenterStart) {
                Text(p.name, fontSize = (s.value * 30).sp, fontWeight = FontWeight.Bold, color = INK, maxLines = 1)
            }
            Area(s, 335, y, 640, y + 44, align = Alignment.CenterEnd) {
                Text(
                    "${fmt(w)} \$  ${signed(diff)}", fontSize = (s.value * 26).sp, fontWeight = FontWeight.Bold,
                    color = if (diff >= 0) Color(0xFF2E7D32) else Color(0xFFC62828), maxLines = 1
                )
            }
        }
        Area(s, 205, 335, 480, 390, onClose)
        Area(s, 628, 10, 672, 56, onClose)
    }
}

// ---------------- Настройки ----------------
@Composable
fun SettingsWindow(st: GameSettings, onChange: (GameSettings) -> Unit, onClose: () -> Unit) {
    WinDialog(onClose, R.drawable.win_settings, 475, 460) { s ->
        val rows = listOf(96, 166, 234)
        val values = listOf(st.players, st.humans, st.rounds)
        val minus = listOf<() -> Unit>(
            { val p = (st.players - 1).coerceAtLeast(2); onChange(st.copy(players = p, humans = st.humans.coerceAtMost(p))) },
            { onChange(st.copy(humans = (st.humans - 1).coerceAtLeast(1))) },
            { onChange(st.copy(rounds = (st.rounds - 5).coerceAtLeast(5))) }
        )
        val plus = listOf<() -> Unit>(
            { onChange(st.copy(players = (st.players + 1).coerceAtMost(4))) },
            { onChange(st.copy(humans = (st.humans + 1).coerceAtMost(st.players))) },
            { onChange(st.copy(rounds = (st.rounds + 5).coerceAtMost(40))) }
        )
        rows.forEachIndexed { i, y ->
            Area(s, 232, y, 277, y + 44, minus[i])
            Area(s, 378, y, 420, y + 44, plus[i])
            Area(s, 280, y, 375, y + 44) {
                Text("${values[i]}", fontSize = (s.value * 40).sp, fontWeight = FontWeight.Bold, color = INK)
            }
        }
        Area(s, 125, 368, 352, 425, onClose)
        Area(s, 426, 22, 468, 64, onClose)
    }
}

// ---------------- Друзья ----------------
@Composable
fun FriendRow(name: String, s: Dp) {
    val rs = s * (350f / 367f)
    Box(Modifier.size(rs * 367, rs * 91)) {
        Image(painterResource(R.drawable.row_friend), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        Area(rs, 15, 11, 89, 86) { Avatar(name, name.hashCode() and 0x7fffffff, rs * 74) }
        Area(rs, 105, 20, 345, 75, align = Alignment.CenterStart) {
            Text(name, fontSize = (rs.value * 34).sp, fontWeight = FontWeight.Bold, color = INK, maxLines = 1)
        }
    }
}

@Composable
fun FriendsWindow(friends: List<String>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    WinDialog(onClose, R.drawable.win_friends, 450, 384) { s ->
        Area(s, 34, 89, 417, 157, {
            val i = Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "Играй со мной в Мини-Монополию! Открой игру и найди мою комнату в списке серверов.")
            ctx.startActivity(Intent.createChooser(i, "Пригласить друзей"))
        })
        Area(s, 34, 197, 417, 297, align = Alignment.TopCenter) {
            if (friends.isEmpty()) {
                Text(
                    "Пока пусто. Игроки, с которыми вы сыграете онлайн или по Bluetooth, появятся здесь.",
                    fontSize = (s.value * 20).sp, color = INK.copy(alpha = 0.7f), textAlign = TextAlign.Center
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(s * 6)) {
                    items(friends) { f -> FriendRow(f, s) }
                }
            }
        }
        Area(s, 122, 304, 344, 360, onClose)
        Area(s, 396, 20, 438, 64, onClose)
    }
}

// ---------------- Обучение ----------------
private val TUTORIAL = listOf(
    "Цель игры" to "У каждого 50 000 \$. За выбранное число раундов заработайте больше всех. Итоговый счёт: деньги + товар по рыночной цене + 50% стоимости зданий.",
    "Карта" to "Красные точки на карте — места для застройки. Нажмите на точку, чтобы построить. Карту можно двигать пальцем и приближать двумя пальцами, за пределы города камера не уйдёт.",
    "Здания" to "Лавка: 40 слотов, продаёт 10% товара за ход, есть аренда. Магазин: 120 слотов, продаёт 25% за ход, без аренды. Съёмная квартира: фиксированный доход за ход.",
    "Товар и аукцион" to "Кнопка «Товар» (внизу) выставляет лот: категория, количество, стартовая цена. Все по очереди ставят или пасуют. Победитель получает товар, деньги идут продавцу. Если никто не купил, лот выкупаете вы сами.",
    "Полки" to "Купленный товар лежит на складе. Нажмите на своё здание и выложите товар на полки: продаётся только то, что лежит на полках. Цены на рынке меняются каждый раунд (значки сверху и кнопка «Рынок»).",
    "Завод" to "Кнопка «Завод»: закажите свой товар дешевле рынка. Выберите категорию, количество и свою цену продажи. Чем выше цена, тем хуже спрос. Один заказ за ход.",
    "Персонал и риски" to "Консультант повышает выручку, бухгалтер снижает аренду и риски. Каждый ход у каждого здания 10% шанс беды: пожар (здание сгорает) или ограбление (теряете часть товара или денег).",
    "Ход" to "«Конец хода» передаёт ход следующему игроку. Доход приходит в начале вашего хода. Играть можно с ботами, по очереди на одном телефоне, по Bluetooth или онлайн через список серверов."
)

@Composable
fun TutorialDialog(onClose: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val (title, text) = TUTORIAL[page]
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = CREAM, titleContentColor = INK, textContentColor = INK,
        title = { Text("${page + 1}/${TUTORIAL.size}  $title", fontWeight = FontWeight.Bold) },
        text = { Text(text, Modifier.verticalScroll(rememberScrollState())) },
        confirmButton = {
            Button(onClick = { if (page < TUTORIAL.size - 1) page++ else onClose() }) {
                Text(if (page < TUTORIAL.size - 1) "Далее" else "Понятно")
            }
        },
        dismissButton = {
            Row {
                if (page > 0) TextButton(onClick = { page-- }) { Text("Назад") }
                TextButton(onClick = onClose) { Text("Пропустить") }
            }
        }
    )
}
