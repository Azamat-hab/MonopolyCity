package com.example.minimonopoly

import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** ВСЕ ЧИСЛА БАЛАНСА ЗДЕСЬ И В BType / Cat НИЖЕ — правьте под себя. */
object Config {
    const val START_MONEY = 50_000
    const val RETAIL_MARKUP = 1.3          // розничная наценка к рыночной цене при продаже
    const val BUILDING_SCORE_SHARE = 0.5   // сколько стоимости здания идёт в итоговый счёт
}

fun fmt(n: Int): String = String.format(Locale.US, "%,d", n).replace(',', ' ')
fun signed(n: Int): String = (if (n >= 0) "+" else "−") + fmt(abs(n))

enum class Cat(val title: String, val icon: String, val base: Int) {
    FOOD("Еда", "🍎", 10),
    CLOTHES("Одежда", "👕", 40),
    TOYS("Игрушки", "🧸", 25),
    FURNITURE("Мебель", "🛋️", 90),
    TECH("Техника", "📱", 150)
}

enum class BType(
    val title: String, val cost: Int, val slots: Int, val percent: Int,
    val rent: Int, val flatIncome: Int, val res: Int
) {
    STALL("Лавка", 4000, 40, 10, 150, 0, R.drawable.b_stall),
    SHOP("Магазин", 12000, 120, 25, 0, 0, R.drawable.b_shop),
    FLAT("Съёмная квартира", 6000, 0, 0, 0, 550, R.drawable.b_apartment);

    fun description(): String =
        if (flatIncome > 0) "Доход ${fmt(flatIncome)} за ход"
        else "$slots слотов, продаёт $percent% товара за ход" +
                (if (rent > 0) ", аренда ${fmt(rent)}/ход" else ", без аренды")
}

class Player(val id: Int, val name: String, val color: Color, val isBot: Boolean) {
    var money by mutableIntStateOf(Config.START_MONEY)
    var warehouse by mutableStateOf<Map<Cat, Int>>(emptyMap())
}

class Building(val spot: Int, val type: BType, val owner: Player) {
    var stock by mutableStateOf<Map<Cat, Int>>(emptyMap())
    val used: Int get() = stock.values.sum()
    val free: Int get() = type.slots - used
}

class Auction(val seller: Player, val cat: Cat, val qty: Int, val startPrice: Int) {
    var price by mutableIntStateOf(startPrice)
    var leader by mutableStateOf<Player?>(null)
    var current by mutableStateOf<Player?>(null)
    val active = mutableListOf<Player>()
}

class Game(val players: List<Player>, val totalRounds: Int) {
    val buildings = mutableStateMapOf<Int, Building>()
    var round by mutableIntStateOf(1)
    var turn by mutableIntStateOf(0)
    var prices by mutableStateOf(Cat.entries.associateWith { it.base })
    var trend by mutableStateOf(Cat.entries.associateWith { 0 })
    var auction by mutableStateOf<Auction?>(null)
    var lotPlaced by mutableStateOf(false)
    var finished by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var log by mutableStateOf<List<String>>(emptyList())

    val current: Player get() = players[turn]

    init { startTurn() }

    fun addLog(s: String) { log = (log + s).takeLast(30) }

    // ---------- ход ----------
    private fun startTurn() {
        lotPlaced = false
        val p = current
        val net = collectIncome(p)
        addLog("${p.name}: доход ${signed(net)}")
        if (!p.isBot) message = "Ход: ${p.name}\nДоход за ход: ${signed(net)}"
    }

    fun endTurn() {
        if (auction != null || finished) return
        turn++
        if (turn >= players.size) {
            turn = 0
            round++
            if (round > totalRounds) { finished = true; return }
            updatePrices()
        }
        startTurn()
    }

    private fun updatePrices() {
        val old = prices
        val new = Cat.entries.associateWith { c ->
            max(1, (c.base * (0.7 + Random.nextDouble() * 0.7)).toInt())
        }
        trend = Cat.entries.associateWith { c -> new.getValue(c).compareTo(old.getValue(c)) }
        prices = new
        addLog("Рынок обновился")
    }

    // ---------- доход ----------
    fun expectedIncome(b: Building): Int {
        if (b.type.flatIncome > 0) return b.type.flatIncome
        var t = 0
        for ((c, n) in b.stock) {
            val sold = min(n, ceil(n * b.type.percent / 100.0).toInt())
            t += (sold * prices.getValue(c) * Config.RETAIL_MARKUP).toInt()
        }
        return t - b.type.rent
    }

    private fun collectIncome(p: Player): Int {
        var total = 0
        for (b in buildings.values.filter { it.owner === p }) {
            if (b.type.flatIncome > 0) { total += b.type.flatIncome; continue }
            val st = b.stock.toMutableMap()
            for ((c, n) in b.stock) {
                val sold = min(n, ceil(n * b.type.percent / 100.0).toInt())
                total += (sold * prices.getValue(c) * Config.RETAIL_MARKUP).toInt()
                if (n - sold > 0) st[c] = n - sold else st.remove(c)
            }
            b.stock = st
            total -= b.type.rent
        }
        p.money += total
        restock(p)
        return total
    }

    /** Раскладывает товар со склада по полкам: сначала магазины, потом лавки. */
    private fun restock(p: Player) {
        val wh = p.warehouse.toMutableMap()
        val mine = buildings.values.filter { it.owner === p && it.type.slots > 0 }
            .sortedByDescending { it.type.slots }
        for (b in mine) {
            var free = b.free
            if (free <= 0) continue
            val st = b.stock.toMutableMap()
            for ((c, n) in wh.toList()) {
                if (free <= 0) break
                val put = min(free, n)
                st[c] = (st[c] ?: 0) + put
                free -= put
                if (n - put > 0) wh[c] = n - put else wh.remove(c)
            }
            b.stock = st
        }
        p.warehouse = wh
    }

    fun freeSlots(p: Player): Int =
        buildings.values.filter { it.owner === p }.sumOf { max(0, it.free) }

    // ---------- здания ----------
    fun buyBuilding(spot: Int, type: BType): String? {
        val p = current
        if (buildings.containsKey(spot)) return "Точка занята"
        if (p.money < type.cost) return "Не хватает денег"
        p.money -= type.cost
        buildings[spot] = Building(spot, type, p)
        restock(p)
        addLog("${p.name} построил: ${type.title}")
        return null
    }

    // ---------- аукцион ----------
    fun minBid(a: Auction): Int =
        if (a.leader == null) a.startPrice else a.price + max(10, a.price / 20)

    private fun nextBidder(a: Auction, afterIdx: Int): Player? {
        for (i in 1..players.size) {
            val p = players[(afterIdx + i) % players.size]
            if (p in a.active && p !== a.leader) return p
        }
        return null
    }

    fun startAuction(cat: Cat, qty: Int, startPrice: Int) {
        val seller = current
        lotPlaced = true
        val a = Auction(seller, cat, qty, startPrice)
        a.active.addAll(players)
        addLog("${seller.name} выставил ${cat.icon}${cat.title} ×$qty от ${fmt(startPrice)}")
        a.current = nextBidder(a, players.indexOf(seller))
        auction = a
        if (a.current == null) finishAuction(a)
    }

    fun bid(amount: Int) {
        val a = auction ?: return
        val p = a.current ?: return
        if (amount < minBid(a) || amount > p.money) return
        a.price = amount
        a.leader = p
        a.current = nextBidder(a, players.indexOf(p))
        if (a.current == null) finishAuction(a)
    }

    fun pass() {
        val a = auction ?: return
        val p = a.current ?: return
        a.active.remove(p)
        a.current = nextBidder(a, players.indexOf(p))
        if (a.current == null) finishAuction(a)
    }

    private fun finishAuction(a: Auction) {
        val leader = a.leader
        val winner: Player
        if (leader != null) {
            winner = leader
            winner.money -= a.price
            if (winner !== a.seller) a.seller.money += a.price
            addLog("${winner.name} купил ${a.cat.icon}×${a.qty} за ${fmt(a.price)}")
        } else if (a.seller.money >= a.startPrice) {
            winner = a.seller
            winner.money -= a.startPrice
            addLog("Никто не купил — ${winner.name} выкупил лот сам за ${fmt(a.startPrice)}")
        } else {
            addLog("Лот снят")
            auction = null
            return
        }
        winner.warehouse = winner.warehouse + (a.cat to ((winner.warehouse[a.cat] ?: 0) + a.qty))
        restock(winner)
        auction = null
    }

    // ---------- итоги ----------
    fun netWorth(p: Player): Int {
        var t = p.money
        p.warehouse.forEach { (c, n) -> t += n * prices.getValue(c) }
        for (b in buildings.values.filter { it.owner === p }) {
            t += (b.type.cost * Config.BUILDING_SCORE_SHARE).toInt()
            b.stock.forEach { (c, n) -> t += n * prices.getValue(c) }
        }
        return t
    }

    // ---------- боты ----------
    fun botBuild() {
        val p = current
        val free = SPOTS.indices.filter { !buildings.containsKey(it) }
        if (free.isEmpty() || round > totalRounds - 3) return
        if (buildings.values.count { it.owner === p } >= 5) return
        val type = when {
            p.money >= BType.SHOP.cost + 15000 -> BType.SHOP
            p.money >= BType.FLAT.cost + 12000 && round <= totalRounds * 0.6 -> BType.FLAT
            p.money >= BType.STALL.cost + 12000 -> BType.STALL
            else -> return
        }
        buyBuilding(free.random(), type)
    }

    fun botLot() {
        val p = current
        val room = freeSlots(p)
        if (room <= 0) return
        val cat = Cat.entries.random()
        val qty = min(room, Random.nextInt(8, 31))
        val start = (qty * prices.getValue(cat) * 0.8).toInt()
        if (p.money >= start) startAuction(cat, qty, start)
    }

    fun botBid() {
        val a = auction ?: return
        val p = a.current ?: return
        if (!p.isBot) return
        val maxPay = a.qty * prices.getValue(a.cat) * Config.RETAIL_MARKUP * 0.7
        val mb = minBid(a)
        if (mb <= maxPay && mb <= p.money - 2000 && freeSlots(p) >= a.qty) bid(mb) else pass()
    }
}
