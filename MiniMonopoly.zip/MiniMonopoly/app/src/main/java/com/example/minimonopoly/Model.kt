package com.example.minimonopoly

import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/** ВЕСЬ БАЛАНС ЗДЕСЬ (и в BType / Cat ниже). */
object Config {
    const val START_MONEY = 50_000
    const val RETAIL_MARKUP = 1.3
    const val CONSULTANT_BONUS = 0.1
    const val CONSULTANT_COST = 8000
    const val ACCOUNTANT_COST = 6000
    const val BUILDING_SCORE_SHARE = 0.5
    const val INCIDENT_CHANCE = 0.10
    const val INCIDENT_CHANCE_ACC = 0.05
    const val FACTORY_COST_SHARE = 0.7
    const val FACTORY_MAX_QTY = 40
}

val PLAYER_COLORS = listOf(Color(0xFFE53935), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFB8C00))

fun fmt(n: Int): String = String.format(Locale.US, "%,d", n).replace(',', ' ')
fun signed(n: Int): String = (if (n >= 0) "+" else "−") + fmt(abs(n))

enum class Cat(val title: String, val base: Int, val color: Long) {
    FOOD("Еда", 10, 0xFFE53935),
    CLOTHES("Одежда", 40, 0xFF1E88E5),
    MATERIALS("Стройматериалы", 60, 0xFF8D6E63),
    CARS("Автомобили", 250, 0xFF3949AB),
    TECH("Электроника", 150, 0xFF455A64),
    TOYS("Игрушки", 25, 0xFFFB8C00),
    FURNITURE("Мебель", 90, 0xFF6D4C41),
    MEDS("Лекарства", 30, 0xFF43A047),
    BOOKS("Книги", 20, 0xFF8E24AA),
    JEWELRY("Украшения", 180, 0xFFFFB300)
}

/** Товар: brand = 0 — обычный, brand > 0 — свой товар с завода по этой цене за штуку. */
data class Item(val cat: Cat, val brand: Int = 0) {
    val key: String get() = "${cat.name}@$brand"
    val label: String get() = if (brand > 0) "${cat.title} (свой, ${brand}\$)" else cat.title

    companion object {
        fun parse(s: String): Item {
            val p = s.split("@")
            return Item(Cat.valueOf(p[0]), p[1].toInt())
        }
    }
}

enum class BType(
    val title: String, val cost: Int, val slots: Int, val percent: Int,
    val rent: Int, val flatIncome: Int, val res: Int
) {
    STALL("Лавка", 4000, 40, 10, 150, 0, R.drawable.b_stall),
    SHOP("Магазин", 12000, 120, 25, 0, 0, R.drawable.b_shop),
    FLAT("Съёмная квартира", 6000, 0, 0, 0, 550, R.drawable.b_apartment)
}

class Player(val id: Int, val name: String, val colorIdx: Int, val isBot: Boolean) {
    val color: Color get() = PLAYER_COLORS[colorIdx % PLAYER_COLORS.size]
    var money by mutableIntStateOf(Config.START_MONEY)
    var warehouse by mutableStateOf<Map<Item, Int>>(emptyMap())
    var consultant by mutableStateOf(false)
    var accountant by mutableStateOf(false)
}

class Building(val spot: Int, val type: BType, val owner: Player) {
    var stock by mutableStateOf<Map<Item, Int>>(emptyMap())
    val used: Int get() = stock.values.sum()
    val free: Int get() = type.slots - used
}

class Auction(val seller: Player, val item: Item, val qty: Int, val startPrice: Int) {
    var price by mutableIntStateOf(startPrice)
    var leader by mutableStateOf<Player?>(null)
    var current by mutableStateOf<Player?>(null)
    val active = mutableListOf<Player>()
}

/** Действие игрока. Передаётся по сети как JSON. */
class Act(val k: String, val i1: Int = 0, val i2: Int = 0, val s: String = "") {
    fun toJson(): String =
        JSONObject().put("k", k).put("i1", i1).put("i2", i2).put("s", s).toString()

    companion object {
        fun parse(js: String): Act {
            val o = JSONObject(js)
            return Act(o.getString("k"), o.optInt("i1"), o.optInt("i2"), o.optString("s"))
        }
    }
}

private fun mapToJson(m: Map<Item, Int>): JSONObject {
    val j = JSONObject()
    for ((k, v) in m) j.put(k.key, v)
    return j
}

private fun mapFromJson(j: JSONObject?): Map<Item, Int> {
    val r = mutableMapOf<Item, Int>()
    if (j == null) return r
    for (k in j.keys()) r[Item.parse(k)] = j.getInt(k)
    return r
}

class Game(
    val players: List<Player>,
    val totalRounds: Int,
    val mapIdx: Int,
    val myId: Int,          // -1 = все люди на одном телефоне, иначе номер этого игрока
    val remote: Boolean     // true = клиент: только показывает состояние хоста
) {
    val buildings = mutableStateMapOf<Int, Building>()
    var round by mutableIntStateOf(1)
    var turn by mutableIntStateOf(0)
    var prices by mutableStateOf(Cat.entries.associateWith { it.base })
    var trend by mutableStateOf(Cat.entries.associateWith { 0 })
    var auction by mutableStateOf<Auction?>(null)
    var lotPlaced by mutableStateOf(false)
    var factoryUsed by mutableStateOf(false)
    var finished by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var messageFor by mutableIntStateOf(-1)
    var income by mutableIntStateOf(0)
    var log by mutableStateOf<List<String>>(emptyList())
    var transport: Transport? = null

    val spots: List<Pair<Float, Float>> get() = MAPS[mapIdx].spots
    val current: Player get() = players[turn]
    val mine: Boolean get() = if (myId >= 0) current.id == myId else !current.isBot
    val busy: Boolean get() = auction != null || message != null
    val canAct: Boolean get() = mine && !busy && !finished
    val viewer: Player get() = if (myId >= 0) players[myId] else current

    init { if (!remote) startTurn() }

    // ================= публичный вход =================
    fun act(a: Act, by: Int? = null): String? {
        val who = by ?: actor(a)
        if (remote) {
            transport?.sendAction(a.toJson())
            return null
        }
        val err = apply(a, who)
        changed()
        return err
    }

    private fun actor(a: Act): Int = when {
        myId >= 0 -> myId
        a.k == "bid" || a.k == "pass" -> auction?.current?.id ?: current.id
        a.k == "ack" -> messageFor
        else -> current.id
    }

    private fun changed() {
        if (!remote) transport?.publishState(toJson())
    }

    fun addLog(s: String) { log = (log + s).takeLast(30) }

    private fun apply(a: Act, by: Int): String? {
        if (finished) return "Игра окончена"
        when (a.k) {
            "bid" -> return doBid(a.i1, by)
            "pass" -> return doPass(by)
            "ack" -> { if (by == messageFor) message = null; return null }
        }
        if (by != current.id) return "Сейчас не ваш ход"
        if (auction != null) return "Идёт аукцион"
        if (message != null) return "Сначала закройте сообщение"
        val p = current
        return when (a.k) {
            "end" -> { endTurn(); null }
            "build" -> buyBuilding(a.i1, BType.valueOf(a.s), p)
            "lot" -> doLot(Cat.valueOf(a.s), a.i1, a.i2, p)
            "stock" -> doStock(a.i1, Item.parse(a.s), a.i2, p)
            "hire" -> doHire(a.s, p)
            "factory" -> doFactory(Cat.valueOf(a.s), a.i1, a.i2, p)
            else -> "Неизвестное действие"
        }
    }

    // ================= ход =================
    private fun startTurn() {
        lotPlaced = false
        factoryUsed = false
        val p = current
        val events = rollIncidents(p)
        val net = collectIncome(p)
        income = net
        if (p.isBot) restock(p)
        addLog("${p.name}: доход ${signed(net)}")
        if (!p.isBot) {
            message = "Доход за ход: ${signed(net)} \$" + events
            messageFor = p.id
        }
    }

    private fun endTurn() {
        turn++
        if (turn >= players.size) {
            turn = 0
            round++
            if (round > totalRounds) { finished = true; return }
            updatePrices()
        }
        startTurn()
    }

    private fun updatePrices() {
        val old = prices
        val new = Cat.entries.associateWith { c ->
            max(1, (c.base * (0.7 + Random.nextDouble() * 0.7)).toInt())
        }
        trend = Cat.entries.associateWith { c -> new.getValue(c).compareTo(old.getValue(c)) }
        prices = new
        addLog("Рынок обновился")
    }

    // ================= риски =================
    private fun rollIncidents(p: Player): String {
        val chance = if (p.accountant) Config.INCIDENT_CHANCE_ACC else Config.INCIDENT_CHANCE
        val sb = StringBuilder()
        for (b in buildings.values.filter { it.owner === p }) {
            if (Random.nextDouble() >= chance) continue
            if (Random.nextBoolean()) {
                buildings.remove(b.spot)
                sb.append("\nПОЖАР! «${b.type.title}» сгорел(а) дотла.")
                addLog("${p.name}: пожар, потерян объект «${b.type.title}»")
            } else if (b.type.slots > 0) {
                b.stock = b.stock.mapValues { it.value / 2 }.filterValues { it > 0 }
                sb.append("\nОГРАБЛЕНИЕ! В «${b.type.title}» унесли половину товара.")
                addLog("${p.name}: ограбление «${b.type.title}»")
            } else {
                val loss = min(p.money, 2000)
                p.money -= loss
                sb.append("\nОГРАБЛЕНИЕ! Из квартиры вынесли ${fmt(loss)} \$.")
                addLog("${p.name}: ограбление квартиры")
            }
        }
        return sb.toString()
    }

    // ================= доход =================
    private fun incomeOf(b: Building, apply: Boolean): Int {
        if (b.type.flatIncome > 0) return b.type.flatIncome
        val owner = b.owner
        val markup = Config.RETAIL_MARKUP + if (owner.consultant) Config.CONSULTANT_BONUS else 0.0
        val st = b.stock.toMutableMap()
        var total = 0
        for ((item, n) in b.stock) {
            val normal = prices.getValue(item.cat) * markup
            val unit: Double
            val mult: Double
            if (item.brand == 0) {
                unit = normal; mult = 1.0
            } else {
                unit = item.brand.toDouble()
                mult = (2.0 - unit / normal).coerceIn(0.2, 1.4)
            }
            val sold = min(n, ceil(n * b.type.percent / 100.0 * mult).toInt())
            total += (sold * unit).toInt()
            if (apply) { if (n - sold > 0) st[item] = n - sold else st.remove(item) }
        }
        if (apply) b.stock = st
        val rent = if (owner.accountant) b.type.rent / 2 else b.type.rent
        return total - rent
    }

    fun expectedIncome(b: Building): Int = incomeOf(b, false)

    private fun collectIncome(p: Player): Int {
        var total = 0
        for (b in buildings.values.filter { it.owner === p }) total += incomeOf(b, true)
        p.money += total
        return total
    }

    // ================= склад и полки =================
    /** Только для ботов: раскладывает товар по полкам автоматически. */
    private fun restock(p: Player) {
        val wh = p.warehouse.toMutableMap()
        val mine = buildings.values.filter { it.owner === p && it.type.slots > 0 }
            .sortedByDescending { it.type.slots }
        for (b in mine) {
            var free = b.free
            if (free <= 0) continue
            val st = b.stock.toMutableMap()
            for ((item, n) in wh.toList()) {
                if (free <= 0) break
                val put = min(free, n)
                st[item] = (st[item] ?: 0) + put
                free -= put
                if (n - put > 0) wh[item] = n - put else wh.remove(item)
            }
            b.stock = st
        }
        p.warehouse = wh
    }

    fun freeSlots(p: Player): Int =
        buildings.values.filter { it.owner === p }.sumOf { max(0, it.free) }

    private fun doStock(spot: Int, item: Item, qty: Int, p: Player): String? {
        val b = buildings[spot] ?: return "Здания нет"
        if (b.owner !== p || b.type.slots == 0) return "Сюда нельзя выложить товар"
        val have = p.warehouse[item] ?: 0
        val put = min(min(qty, have), b.free)
        if (put <= 0) return "Нет места или товара на складе"
        b.stock = b.stock + (item to ((b.stock[item] ?: 0) + put))
        val left = have - put
        p.warehouse = if (left > 0) p.warehouse + (item to left) else p.warehouse - item
        return null
    }

    // ================= здания =================
    private fun buyBuilding(spot: Int, type: BType, p: Player): String? {
        if (spot !in spots.indices) return "Нет такой точки"
        if (buildings.containsKey(spot)) return "Точка занята"
        if (p.money < type.cost) return "Не хватает денег"
        p.money -= type.cost
        buildings[spot] = Building(spot, type, p)
        if (p.isBot) restock(p)
        addLog("${p.name} построил: ${type.title}")
        return null
    }

    private fun doHire(role: String, p: Player): String? {
        val cons = role == "cons"
        if (cons && p.consultant || !cons && p.accountant) return "Уже нанят"
        val cost = if (cons) Config.CONSULTANT_COST else Config.ACCOUNTANT_COST
        if (p.money < cost) return "Не хватает денег"
        p.money -= cost
        if (cons) p.consultant = true else p.accountant = true
        addLog("${p.name} нанял ${if (cons) "консультанта" else "бухгалтера"}")
        return null
    }

    // ================= завод =================
    fun factoryCost(cat: Cat, qty: Int): Int =
        (qty * prices.getValue(cat) * Config.FACTORY_COST_SHARE).toInt()

    private fun doFactory(cat: Cat, qty: Int, price: Int, p: Player): String? {
        if (factoryUsed) return "Завод уже работал в этом ходу"
        if (qty !in 1..Config.FACTORY_MAX_QTY || price < 1) return "Неверные параметры"
        val cost = factoryCost(cat, qty)
        if (p.money < cost) return "Не хватает денег"
        p.money -= cost
        factoryUsed = true
        val item = Item(cat, price)
        p.warehouse = p.warehouse + (item to ((p.warehouse[item] ?: 0) + qty))
        addLog("${p.name} заказал на заводе ${cat.title} ×$qty по ${price}\$")
        return null
    }

    // ================= аукцион =================
    fun minBid(a: Auction): Int =
        if (a.leader == null) a.startPrice else a.price + max(10, a.price / 20)

    private fun nextBidder(a: Auction, afterIdx: Int): Player? {
        for (i in 1..players.size) {
            val p = players[(afterIdx + i) % players.size]
            if (p in a.active && p !== a.leader) return p
        }
        return null
    }

    private fun doLot(cat: Cat, qty: Int, start: Int, p: Player): String? {
        if (lotPlaced) return "Лот уже выставлен в этом ходу"
        if (qty !in 1..120 || start < 1) return "Неверные параметры"
        if (p.money < start) return "Не хватает денег на выкуп"
        lotPlaced = true
        val a = Auction(p, Item(cat), qty, start)
        a.active.addAll(players)
        addLog("${p.name} выставил ${cat.title} ×$qty от ${fmt(start)}")
        a.current = nextBidder(a, players.indexOf(p))
        auction = a
        if (a.current == null) finishAuction(a)
        return null
    }

    private fun doBid(amount: Int, by: Int): String? {
        val a = auction ?: return "Нет аукциона"
        val p = a.current ?: return "Нет аукциона"
        if (p.id != by) return "Сейчас ставит другой игрок"
        if (amount < minBid(a) || amount > p.money) return "Неверная ставка"
        a.price = amount
        a.leader = p
        a.current = nextBidder(a, players.indexOf(p))
        if (a.current == null) finishAuction(a)
        return null
    }

    private fun doPass(by: Int): String? {
        val a = auction ?: return "Нет аукциона"
        val p = a.current ?: return "Нет аукциона"
        if (p.id != by) return "Сейчас ставит другой игрок"
        a.active.remove(p)
        a.current = nextBidder(a, players.indexOf(p))
        if (a.current == null) finishAuction(a)
        return null
    }

    private fun finishAuction(a: Auction) {
        val leader = a.leader
        val winner: Player
        if (leader != null) {
            winner = leader
            winner.money -= a.price
            if (winner !== a.seller) a.seller.money += a.price
            addLog("${winner.name} купил ${a.item.cat.title} ×${a.qty} за ${fmt(a.price)}")
        } else if (a.seller.money >= a.startPrice) {
            winner = a.seller
            winner.money -= a.startPrice
            addLog("Никто не купил — ${winner.name} выкупил лот сам за ${fmt(a.startPrice)}")
        } else {
            addLog("Лот снят")
            auction = null
            return
        }
        winner.warehouse = winner.warehouse + (a.item to ((winner.warehouse[a.item] ?: 0) + a.qty))
        if (winner.isBot) restock(winner)
        auction = null
    }

    // ================= итоги =================
    fun netWorth(p: Player): Int {
        var t = p.money
        p.warehouse.forEach { (i, n) -> t += n * prices.getValue(i.cat) }
        for (b in buildings.values.filter { it.owner === p }) {
            t += (b.type.cost * Config.BUILDING_SCORE_SHARE).toInt()
            b.stock.forEach { (i, n) -> t += n * prices.getValue(i.cat) }
        }
        return t
    }

    // ================= боты =================
    fun botBuild() {
        val p = current
        if (!p.isBot || auction != null || finished) return
        if (round > totalRounds - 3) return
        if (p.money > Config.CONSULTANT_COST + 20000 && !p.consultant && Random.nextInt(100) < 15) {
            act(Act("hire", s = "cons"), p.id)
        }
        if (p.money > Config.ACCOUNTANT_COST + 20000 && !p.accountant && Random.nextInt(100) < 15) {
            act(Act("hire", s = "acc"), p.id)
        }
        val free = spots.indices.filter { !buildings.containsKey(it) }
        if (free.isEmpty() || buildings.values.count { it.owner === p } >= 6) return
        val options = BType.entries.filter {
            p.money >= it.cost + 8000 && (it != BType.FLAT || round <= totalRounds * 0.7)
        }
        if (options.isEmpty() || Random.nextInt(100) < 30) return
        act(Act("build", free.random(), 0, options.random().name), p.id)
    }

    fun botLot() {
        val p = current
        if (!p.isBot || auction != null || finished) return
        val room = freeSlots(p)
        if (room <= 0) return
        val cat = Cat.entries.random()
        val qty = min(room, Random.nextInt(8, 31))
        val start = max(1, (qty * prices.getValue(cat) * 0.8).toInt())
        if (p.money >= start) act(Act("lot", qty, start, cat.name), p.id)
    }

    fun botBid() {
        val a = auction ?: return
        val p = a.current ?: return
        if (!p.isBot) return
        val maxPay = a.qty * prices.getValue(a.item.cat) * Config.RETAIL_MARKUP * 0.7
        val mb = minBid(a)
        if (mb <= maxPay && mb <= p.money - 2000 && freeSlots(p) >= a.qty) {
            act(Act("bid", mb), p.id)
        } else {
            act(Act("pass"), p.id)
        }
    }

    // ================= сериализация =================
    fun toJson(): String {
        val o = JSONObject()
        o.put("map", mapIdx).put("rounds", totalRounds).put("round", round).put("turn", turn)
            .put("lot", lotPlaced).put("fu", factoryUsed).put("fin", finished)
            .put("income", income).put("msgFor", messageFor)
        message?.let { o.put("msg", it) }
        val pr = JSONObject(); val tr = JSONObject()
        for (c in Cat.entries) { pr.put(c.name, prices.getValue(c)); tr.put(c.name, trend.getValue(c)) }
        o.put("prices", pr).put("trend", tr)
        val pa = JSONArray()
        for (p in players) {
            pa.put(
                JSONObject().put("n", p.name).put("c", p.colorIdx).put("b", p.isBot)
                    .put("m", p.money).put("wh", mapToJson(p.warehouse))
                    .put("cons", p.consultant).put("acc", p.accountant)
            )
        }
        o.put("players", pa)
        val ba = JSONArray()
        for (b in buildings.values) {
            ba.put(
                JSONObject().put("s", b.spot).put("t", b.type.name).put("o", b.owner.id)
                    .put("st", mapToJson(b.stock))
            )
        }
        o.put("bld", ba)
        auction?.let { a ->
            val aj = JSONObject().put("sel", a.seller.id).put("it", a.item.key).put("q", a.qty)
                .put("sp", a.startPrice).put("p", a.price)
                .put("l", a.leader?.id ?: -1).put("c", a.current?.id ?: -1)
            val act = JSONArray()
            a.active.forEach { act.put(it.id) }
            o.put("auc", aj.put("act", act))
        }
        val la = JSONArray(); log.forEach { la.put(it) }
        o.put("log", la)
        return o.toString()
    }

    fun loadJson(s: String) {
        val o = JSONObject(s)
        round = o.getInt("round"); turn = o.getInt("turn")
        lotPlaced = o.getBoolean("lot"); factoryUsed = o.optBoolean("fu")
        finished = o.getBoolean("fin"); income = o.getInt("income")
        messageFor = o.optInt("msgFor", -1)
        message = if (o.has("msg")) o.getString("msg") else null
        val pr = o.getJSONObject("prices"); val tr = o.getJSONObject("trend")
        prices = Cat.entries.associateWith { pr.getInt(it.name) }
        trend = Cat.entries.associateWith { tr.getInt(it.name) }
        val pa = o.getJSONArray("players")
        for (i in 0 until pa.length()) {
            val j = pa.getJSONObject(i); val p = players[i]
            p.money = j.getInt("m")
            p.warehouse = mapFromJson(j.getJSONObject("wh"))
            p.consultant = j.getBoolean("cons"); p.accountant = j.getBoolean("acc")
        }
        buildings.clear()
        val ba = o.getJSONArray("bld")
        for (i in 0 until ba.length()) {
            val j = ba.getJSONObject(i)
            val b = Building(j.getInt("s"), BType.valueOf(j.getString("t")), players[j.getInt("o")])
            b.stock = mapFromJson(j.getJSONObject("st"))
            buildings[b.spot] = b
        }
        auction = if (o.has("auc")) {
            val j = o.getJSONObject("auc")
            val a = Auction(players[j.getInt("sel")], Item.parse(j.getString("it")), j.getInt("q"), j.getInt("sp"))
            a.price = j.getInt("p")
            a.leader = players.getOrNull(j.getInt("l"))
            a.current = players.getOrNull(j.getInt("c"))
            val act = j.getJSONArray("act")
            for (i in 0 until act.length()) a.active.add(players[act.getInt(i)])
            a
        } else null
        val la = o.getJSONArray("log")
        log = (0 until la.length()).map { la.getString(it) }
    }

    companion object {
        fun fromJson(s: String, myId: Int): Game {
            val o = JSONObject(s)
            val pa = o.getJSONArray("players")
            val ps = (0 until pa.length()).map { i ->
                val j = pa.getJSONObject(i)
                Player(i, j.getString("n"), j.getInt("c"), j.getBoolean("b"))
            }
            val g = Game(ps, o.getInt("rounds"), o.getInt("map"), myId, true)
            g.loadJson(s)
            return g
        }
    }
}
