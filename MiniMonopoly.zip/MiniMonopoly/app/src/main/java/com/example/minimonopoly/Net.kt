package com.example.minimonopoly

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * Хост-авторитарная схема: игра считается на устройстве хоста,
 * клиенты шлют действия (sendAction) и получают готовое состояние (onState).
 */
abstract class Transport {
    var onLobby: ((List<String>, Int) -> Unit)? = null   // имена игроков, мой номер
    var onState: ((String) -> Unit)? = null              // клиент: новое состояние игры
    var onAction: ((String, Int) -> Unit)? = null        // хост: действие клиента, номер клиента
    var onError: ((String) -> Unit)? = null
    abstract val isHost: Boolean
    abstract fun sendAction(json: String)
    abstract fun publishState(json: String)
    open fun startGame(stateJson: String) = publishState(stateJson)
    abstract fun close()
}

// ====================== Firebase ======================
object Online {
    data class Room(val code: String, val name: String, val host: String, val count: Int)

    fun available(ctx: Context): Boolean = FirebaseApp.getApps(ctx).isNotEmpty()

    private fun rooms() = FirebaseFirestore.getInstance().collection("rooms")

    fun listen(onList: (List<Room>) -> Unit, onErr: (String) -> Unit): ListenerRegistration =
        rooms().whereEqualTo("status", "open").addSnapshotListener { snap, err ->
            if (err != null) { onErr(err.message ?: "Ошибка сети"); return@addSnapshotListener }
            val now = System.currentTimeMillis()
            val list = snap?.documents?.mapNotNull { d ->
                val created = d.getLong("created") ?: 0L
                if (now - created > 3 * 3600_000L) null
                else Room(
                    d.id, d.getString("name") ?: "Комната", d.getString("host") ?: "",
                    (d.get("lobby") as? List<*>)?.size ?: 0
                )
            } ?: emptyList()
            onList(list)
        }

    fun create(roomName: String, uid: String, name: String): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val code = (1..5).map { chars.random() }.joinToString("")
        rooms().document(code).set(
            mapOf(
                "name" to roomName, "host" to name, "status" to "open",
                "created" to System.currentTimeMillis(),
                "lobby" to listOf("$uid|$name"), "state" to ""
            )
        )
        return code
    }

    fun join(code: String, uid: String, name: String, done: (Boolean, String?) -> Unit) {
        val ref = rooms().document(code)
        ref.get().addOnSuccessListener { d ->
            val lobby = (d.get("lobby") as? List<*>)?.map { it.toString() } ?: emptyList()
            when {
                !d.exists() -> done(false, "Комната не найдена")
                d.getString("status") != "open" -> done(false, "Игра уже идёт")
                lobby.any { it.startsWith("$uid|") } -> done(true, null)
                lobby.size >= 4 -> done(false, "Комната заполнена")
                else -> ref.update("lobby", FieldValue.arrayUnion("$uid|$name"))
                    .addOnSuccessListener { done(true, null) }
                    .addOnFailureListener { done(false, it.message) }
            }
        }.addOnFailureListener { done(false, it.message) }
    }
}

class FirebaseNet(
    private val code: String,
    override val isHost: Boolean,
    private val uid: String
) : Transport() {
    private val room = FirebaseFirestore.getInstance().collection("rooms").document(code)
    private val regs = mutableListOf<ListenerRegistration>()
    private var myId = -1

    init {
        regs += room.addSnapshotListener { snap, err ->
            if (err != null) { onError?.invoke(err.message ?: "Ошибка сети"); return@addSnapshotListener }
            if (snap == null || !snap.exists()) return@addSnapshotListener
            val lobby = (snap.get("lobby") as? List<*>)?.map { it.toString() } ?: emptyList()
            myId = lobby.indexOfFirst { it.substringBefore("|") == uid }
            onLobby?.invoke(lobby.map { it.substringAfter("|") }, myId)
            val st = snap.getString("state")
            if (!isHost && !st.isNullOrEmpty()) onState?.invoke(st)
        }
        if (isHost) {
            regs += room.collection("actions").orderBy("t").addSnapshotListener { snap, _ ->
                snap?.documentChanges?.forEach { ch ->
                    if (ch.type == DocumentChange.Type.ADDED) {
                        val a = ch.document.getString("a")
                        val by = (ch.document.getLong("by") ?: -1L).toInt()
                        ch.document.reference.delete()
                        if (a != null) onAction?.invoke(a, by)
                    }
                }
            }
        }
    }

    override fun sendAction(json: String) {
        room.collection("actions").add(
            mapOf("a" to json, "by" to myId, "t" to System.currentTimeMillis())
        )
    }

    override fun publishState(json: String) {
        room.update("state", json)
    }

    override fun startGame(stateJson: String) {
        room.update(mapOf("status" to "playing", "state" to stateJson))
    }

    override fun close() {
        regs.forEach { it.remove() }
        regs.clear()
        if (isHost) room.delete()
    }
}

// ====================== Bluetooth ======================
@SuppressLint("MissingPermission")
class BtNet(
    private val adapter: BluetoothAdapter,
    override val isHost: Boolean,
    private val myName: String
) : Transport() {
    private val uuid = UUID.fromString("8c1d2e3f-5a6b-4c7d-9e8f-0a1b2c3d4e5f")
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private class Conn(val socket: BluetoothSocket) {
        val reader = BufferedReader(InputStreamReader(socket.inputStream))
        private val writer = OutputStreamWriter(socket.outputStream)
        var name = ""
        fun send(s: String) {
            try {
                synchronized(writer) { writer.write(s + "\n"); writer.flush() }
            } catch (e: Exception) { }
        }
    }

    private val clients = mutableListOf<Conn>()
    private var server: BluetoothServerSocket? = null
    private var conn: Conn? = null
    @Volatile private var closed = false

    // ---- хост ----
    fun startHost() {
        main.post { onLobby?.invoke(listOf(myName), 0) }
        thread(isDaemon = true) {
            try {
                val ss = adapter.listenUsingRfcommWithServiceRecord("MiniMonopoly", uuid)
                server = ss
                while (!closed && clients.size < 3) {
                    val c = Conn(ss.accept())
                    synchronized(clients) { clients.add(c) }
                    thread(isDaemon = true) { readHost(c) }
                }
            } catch (e: Exception) {
                if (!closed) main.post { onError?.invoke("Bluetooth: ${e.message}") }
            }
        }
    }

    private fun readHost(c: Conn) {
        try {
            while (true) {
                val line = c.reader.readLine() ?: break
                val o = JSONObject(line)
                when (o.getString("t")) {
                    "join" -> { c.name = o.getString("name"); broadcastLobby() }
                    "act" -> {
                        val idx = synchronized(clients) { clients.indexOf(c) } + 1
                        val a = o.getString("a")
                        main.post { onAction?.invoke(a, idx) }
                    }
                }
            }
        } catch (e: Exception) { }
    }

    private fun broadcastLobby() {
        val names = listOf(myName) + synchronized(clients) { clients.map { it.name } }
        main.post { onLobby?.invoke(names, 0) }
        io.execute {
            synchronized(clients) {
                clients.forEachIndexed { i, c ->
                    c.send(
                        JSONObject().put("t", "lobby").put("names", JSONArray(names))
                            .put("id", i + 1).toString()
                    )
                }
            }
        }
    }

    // ---- клиент ----
    fun connect(device: BluetoothDevice) {
        thread(isDaemon = true) {
            try {
                adapter.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(uuid)
                s.connect()
                val c = Conn(s)
                conn = c
                c.send(JSONObject().put("t", "join").put("name", myName).toString())
                while (true) {
                    val line = c.reader.readLine() ?: break
                    val o = JSONObject(line)
                    when (o.getString("t")) {
                        "lobby" -> {
                            val arr = o.getJSONArray("names")
                            val names = (0 until arr.length()).map { arr.getString(it) }
                            val id = o.getInt("id")
                            main.post { onLobby?.invoke(names, id) }
                        }
                        "state" -> {
                            val st = o.getString("s")
                            main.post { onState?.invoke(st) }
                        }
                    }
                }
            } catch (e: Exception) {
                if (!closed) main.post { onError?.invoke("Нет соединения: ${e.message}") }
            }
        }
    }

    override fun sendAction(json: String) {
        val c = conn ?: return
        if (closed) return
        io.execute { c.send(JSONObject().put("t", "act").put("a", json).toString()) }
    }

    override fun publishState(json: String) {
        if (closed) return
        io.execute {
            val msg = JSONObject().put("t", "state").put("s", json).toString()
            synchronized(clients) { clients.forEach { it.send(msg) } }
        }
    }

    override fun close() {
        closed = true
        try { server?.close() } catch (e: Exception) { }
        try { conn?.socket?.close() } catch (e: Exception) { }
        synchronized(clients) { clients.forEach { try { it.socket.close() } catch (e: Exception) { } } }
        io.shutdown()
    }
}
