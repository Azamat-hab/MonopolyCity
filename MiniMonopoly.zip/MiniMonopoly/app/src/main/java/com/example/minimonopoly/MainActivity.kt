package com.example.minimonopoly

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

data class GameSettings(
    val players: Int = 3,
    val humans: Int = 1,
    val rounds: Int = 15,
    val name: String = "Игрок 1"
)

enum class Screen { MENU, LOBBY, GAME }

@SuppressLint("MissingPermission")
@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("mm", Context.MODE_PRIVATE) }
    val uid = remember {
        prefs.getString("uid", null)
            ?: UUID.randomUUID().toString().take(8).also { prefs.edit().putString("uid", it).apply() }
    }
    var settings by remember {
        mutableStateOf(GameSettings(name = prefs.getString("name", "Игрок 1") ?: "Игрок 1"))
    }
    var screen by remember { mutableStateOf(Screen.MENU) }
    var game by remember { mutableStateOf<Game?>(null) }
    var transport by remember { mutableStateOf<Transport?>(null) }
    var lobbyNames by remember { mutableStateOf(listOf<String>()) }
    var lobbyId by remember { mutableIntStateOf(-1) }
    var lobbyTitle by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var tutorial by remember { mutableStateOf(!prefs.getBoolean("tut", false)) }
    var roomName by remember { mutableStateOf("") }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun leave() {
        transport?.close()
        transport = null
        game = null
        screen = Screen.MENU
    }

    fun attach(t: Transport, title: String) {
        transport = t
        lobbyTitle = title
        lobbyNames = emptyList()
        lobbyId = -1
        game = null
        t.onLobby = { names, id -> lobbyNames = names; lobbyId = id }
        t.onState = { s ->
            val g = game
            if (g == null) {
                val ng = Game.fromJson(s, lobbyId)
                ng.transport = t
                game = ng
                screen = Screen.GAME
            } else g.loadJson(s)
        }
        t.onAction = { a, by -> game?.act(Act.parse(a), by) }
        t.onError = { msg -> toast(msg) }
        screen = Screen.LOBBY
    }

    fun startLocal() {
        val ps = (0 until settings.players).map { i ->
            val bot = i >= settings.humans
            val name = when {
                i == 0 -> settings.name
                bot -> "Бот ${i - settings.humans + 1}"
                else -> "Игрок ${i + 1}"
            }
            Player(i, name, i, bot)
        }
        game = Game(ps, settings.rounds, Random.nextInt(MAPS.size), -1, false)
        screen = Screen.GAME
    }

    fun startHosted(bots: Int, rounds: Int) {
        val humans = lobbyNames.size
        val ps = lobbyNames.mapIndexed { i, n -> Player(i, n, i, false) } +
                (0 until bots).map { b -> Player(humans + b, "Бот ${b + 1}", humans + b, true) }
        val g = Game(ps, rounds, Random.nextInt(MAPS.size), 0, false)
        g.transport = transport
        game = g
        screen = Screen.GAME
        transport?.startGame(g.toJson())
    }

    fun createOnline() {
        val title = roomName.ifBlank { "Комната ${settings.name}" }
        val code = Online.create(title, uid, settings.name)
        attach(FirebaseNet(code, true, uid), "$title  [$code]")
    }

    fun joinOnline(r: Online.Room) {
        Online.join(r.code, uid, settings.name.replace("|", " ")) { ok, err ->
            if (ok) attach(FirebaseNet(r.code, false, uid), "${r.name}  [${r.code}]")
            else toast(err ?: "Не удалось войти")
        }
    }

    fun btAdapter(): BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    val btPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) dialog = "bt" else toast("Без разрешения Bluetooth играть нельзя")
    }

    BackHandler(enabled = screen != Screen.MENU) {
        if (screen == Screen.LOBBY) leave()
    }

    when (screen) {
        Screen.MENU -> MenuScreen(
            hasFirebase = Online.available(ctx),
            onPlay = { startLocal() },
            onProfile = { dialog = "profile" },
            onFriends = { dialog = "friends" },
            onSettings = { dialog = "settings" },
            onTutorial = { tutorial = true },
            onCreate = { roomName = ""; dialog = "create" },
            onJoin = { joinOnline(it) },
            onBluetooth = {
                if (Build.VERSION.SDK_INT >= 31 &&
                    ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) btPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
                else dialog = "bt"
            }
        )
        Screen.LOBBY -> LobbyScreen(
            title = lobbyTitle, names = lobbyNames, isHost = transport?.isHost == true,
            defaultRounds = settings.rounds,
            onStart = { bots, rounds -> startHosted(bots, rounds) },
            onLeave = { leave() }
        )
        Screen.GAME -> game?.let { GameScreen(it) { leave() } }
    }

    // ----- диалоги главного экрана -----
    when (dialog) {
        "profile" -> ProfileWindow(settings.name, onSave = {
            settings = settings.copy(name = it)
            prefs.edit().putString("name", it).apply()
            dialog = null
        }, onClose = { dialog = null })
        "friends" -> FriendsWindow(settings.name) { dialog = null }
        "settings" -> SettingsWindow(settings, { settings = it }) { dialog = null }
        "create" -> AlertDialog(
            onDismissRequest = { dialog = null },
            containerColor = CREAM, titleContentColor = INK, textContentColor = INK,
            title = { Text("Новый сервер") },
            text = {
                OutlinedTextField(
                    value = roomName, onValueChange = { roomName = it.take(20) },
                    label = { Text("Название комнаты") }, singleLine = true
                )
            },
            confirmButton = { Button(onClick = { dialog = null; createOnline() }) { Text("Создать") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Отмена") } }
        )
        "bt" -> {
            val adapter = btAdapter()
            CreamDialog("Bluetooth", onClose = { dialog = null }) {
                if (adapter == null) Text("На этом устройстве нет Bluetooth.")
                else if (!adapter.isEnabled) Text("Включите Bluetooth и откройте окно снова.")
                else {
                    Text(
                        "1) Сначала свяжите телефоны в настройках Bluetooth Android (сопряжение).\n" +
                                "2) Один создаёт игру, остальные подключаются к нему из списка.",
                        fontSize = 12.sp
                    )
                    Button(onClick = {
                        dialog = null
                        val t = BtNet(adapter, true, settings.name)
                        attach(t, "Bluetooth: ваша игра")
                        t.startHost()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Создать игру (я хост)") }
                    Text("Подключиться к:", fontWeight = FontWeight.Bold)
                    val devices = adapter.bondedDevices.toList()
                    if (devices.isEmpty()) Text("Нет сопряжённых устройств.", fontSize = 12.sp)
                    devices.forEach { d ->
                        OutlinedButton(onClick = {
                            dialog = null
                            val t = BtNet(adapter, false, settings.name)
                            attach(t, "Bluetooth: ${d.name}")
                            t.connect(d)
                        }, modifier = Modifier.fillMaxWidth()) { Text(d.name ?: d.address) }
                    }
                }
            }
        }
    }

    if (tutorial) {
        TutorialDialog {
            tutorial = false
            prefs.edit().putBoolean("tut", true).apply()
        }
    }
}

@Composable
fun MenuScreen(
    hasFirebase: Boolean,
    onPlay: () -> Unit, onProfile: () -> Unit, onFriends: () -> Unit, onSettings: () -> Unit,
    onTutorial: () -> Unit, onCreate: () -> Unit, onJoin: (Online.Room) -> Unit, onBluetooth: () -> Unit
) {
    val ctx = LocalContext.current
    var rooms by remember { mutableStateOf(listOf<Online.Room>()) }
    var error by remember { mutableStateOf<String?>(null) }
    DisposableEffect(hasFirebase) {
        val reg = if (hasFirebase) Online.listen({ rooms = it; error = null }, { error = it }) else null
        onDispose { reg?.remove() }
    }
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.bg_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            // левая половина: заголовок и кнопки
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Text("МИНИ-МОНОПОЛИЯ", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Image(painterResource(R.drawable.btn_play), "Играть", Modifier.size(130.dp).clickable { onPlay() })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Image(painterResource(R.drawable.btn_profile), "Профиль", Modifier.size(78.dp).clickable { onProfile() })
                    Image(painterResource(R.drawable.btn_friends), "Друзья", Modifier.size(78.dp).clickable { onFriends() })
                    Image(painterResource(R.drawable.btn_settings), "Настройки", Modifier.size(78.dp).clickable { onSettings() })
                }
                TextButton(onClick = onTutorial) { Text("? Обучение", color = Color.White) }
            }
            // правая половина: серверы
            Surface(
                Modifier.weight(1f).fillMaxHeight(),
                shape = RoundedCornerShape(16.dp), color = Color(0xCC16213A)
            ) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Серверы", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = onCreate, enabled = hasFirebase, contentPadding = PaddingValues(horizontal = 10.dp)) {
                            Text("Создать", fontSize = 12.sp)
                        }
                        Button(
                            onClick = onBluetooth,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B2A6B)),
                            contentPadding = PaddingValues(horizontal = 10.dp)
                        ) { Text("Bluetooth", fontSize = 12.sp) }
                    }
                    if (!hasFirebase) {
                        Text(
                            "Онлайн не настроен: добавьте google-services.json (инструкция в README). Одиночная игра, игра вдвоём на одном телефоне и Bluetooth работают и так.",
                            color = Color(0xFFFFCC80), fontSize = 12.sp
                        )
                    } else {
                        error?.let { Text("Ошибка: $it", color = Color(0xFFFF8A80), fontSize = 12.sp) }
                        if (rooms.isEmpty()) Text("Открытых комнат пока нет. Создайте свою!", color = Color(0xFFB0BEC5), fontSize = 13.sp)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(rooms) { r ->
                                Surface(
                                    Modifier.fillMaxWidth().clickable { onJoin(r) },
                                    shape = RoundedCornerShape(10.dp), color = Color(0xFF2A3A63)
                                ) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(r.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                                            Text("Хост: ${r.host}", color = Color(0xFFB0BEC5), fontSize = 11.sp, maxLines = 1)
                                        }
                                        Text("${r.count}/4", color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LobbyScreen(
    title: String, names: List<String>, isHost: Boolean, defaultRounds: Int,
    onStart: (Int, Int) -> Unit, onLeave: () -> Unit
) {
    var bots by remember { mutableIntStateOf(0) }
    var rounds by remember { mutableIntStateOf(defaultRounds) }
    val humans = names.size
    val minBots = maxOf(0, 2 - humans)
    val maxBots = maxOf(0, 4 - humans)
    val b = bots.coerceIn(minBots, maxBots)
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.bg_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(16.dp), color = CREAM, modifier = Modifier.widthIn(max = 460.dp)) {
                Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = INK)
                    Text("Игроки (${names.size}/4):", color = INK)
                    names.forEachIndexed { i, n -> Text("${i + 1}. $n${if (i == 0) " (хост)" else ""}", color = INK, fontWeight = FontWeight.Bold) }
                    if (isHost) {
                        Text("Ботов: $b", color = INK)
                        if (maxBots > minBots) {
                            Slider(value = b.toFloat(), onValueChange = { bots = it.toInt() }, valueRange = minBots.toFloat()..maxBots.toFloat(), steps = maxBots - minBots - 1)
                        }
                        Text("Раундов: $rounds", color = INK)
                        Slider(value = rounds.toFloat(), onValueChange = { rounds = (it / 5).toInt() * 5 }, valueRange = 5f..40f, steps = 6)
                        Button(onClick = { onStart(b, rounds) }, enabled = humans + b >= 2, modifier = Modifier.fillMaxWidth()) { Text("Старт") }
                    } else {
                        Text("Ждём, пока хост запустит игру…", color = INK)
                    }
                    OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth()) { Text("Выйти") }
                }
            }
        }
    }
}
