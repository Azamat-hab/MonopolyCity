package com.example.minimonopoly

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

data class GameSettings(
    val players: Int = 3,
    val humans: Int = 1,
    val rounds: Int = 15,
    val name: String = "Игрок 1"
)

enum class Screen { MENU, SETTINGS, GAME }

private val PLAYER_COLORS = listOf(Color(0xFFE53935), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFB8C00))

fun newGame(s: GameSettings): Game {
    val list = (0 until s.players).map { i ->
        val bot = i >= s.humans
        val name = when {
            i == 0 -> s.name
            bot -> "Бот ${i - s.humans + 1}"
            else -> "Игрок ${i + 1}"
        }
        Player(i, name, PLAYER_COLORS[i], bot)
    }
    return Game(list, s.rounds)
}

@Composable
fun App() {
    var screen by remember { mutableStateOf(Screen.MENU) }
    var settings by remember { mutableStateOf(GameSettings()) }
    var game by remember { mutableStateOf<Game?>(null) }
    var dialog by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = screen != Screen.MENU) { screen = Screen.MENU }

    when (screen) {
        Screen.MENU -> MenuScreen(
            onPlay = { game = newGame(settings); screen = Screen.GAME },
            onProfile = { dialog = "profile" },
            onFriends = { dialog = "friends" },
            onSettings = { screen = Screen.SETTINGS }
        )
        Screen.SETTINGS -> SettingsScreen(settings, { settings = it }) { screen = Screen.MENU }
        Screen.GAME -> game?.let { GameScreen(it) { screen = Screen.MENU } }
    }

    if (dialog == "friends") {
        AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Ок") } },
            title = { Text("Друзья") },
            text = { Text("Онлайн-мультиплеер через Firebase появится в следующей версии. Пока играйте по очереди на одном телефоне или с ботами.") }
        )
    }
    if (dialog == "profile") {
        var name by remember { mutableStateOf(settings.name) }
        AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = {
                TextButton(onClick = {
                    settings = settings.copy(name = name.ifBlank { "Игрок 1" }.take(14)); dialog = null
                }) { Text("Сохранить") }
            },
            title = { Text("Профиль") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it.take(14) }, label = { Text("Ваше имя") }, singleLine = true) }
        )
    }
}

@Composable
fun MenuScreen(onPlay: () -> Unit, onProfile: () -> Unit, onFriends: () -> Unit, onSettings: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.bg_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("МИНИ-МОНОПОЛИЯ", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Spacer(Modifier.height(28.dp))
            Image(painterResource(R.drawable.btn_play), "Играть", Modifier.size(200.dp).clickable { onPlay() })
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(painterResource(R.drawable.btn_profile), "Профиль", Modifier.size(96.dp).clickable { onProfile() })
                Image(painterResource(R.drawable.btn_friends), "Друзья", Modifier.size(96.dp).clickable { onFriends() })
                Image(painterResource(R.drawable.btn_settings), "Настройки", Modifier.size(96.dp).clickable { onSettings() })
            }
        }
    }
}

@Composable
fun Stepper(label: String, value: Int, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 16.sp)
        OutlinedButton(onClick = onMinus, Modifier.size(42.dp), contentPadding = PaddingValues(0.dp)) { Text("−") }
        Text("$value", Modifier.width(48.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        OutlinedButton(onClick = onPlus, Modifier.size(42.dp), contentPadding = PaddingValues(0.dp)) { Text("+") }
    }
}

@Composable
fun SettingsScreen(s: GameSettings, onChange: (GameSettings) -> Unit, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.bg_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Surface(shape = MaterialTheme.shapes.large, color = Color(0xFFFFF3E0)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Настройки игры", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Stepper("Игроков", s.players,
                        { val p = (s.players - 1).coerceAtLeast(2); onChange(s.copy(players = p, humans = s.humans.coerceAtMost(p))) },
                        { onChange(s.copy(players = (s.players + 1).coerceAtMost(4))) })
                    Stepper("Из них людей", s.humans,
                        { onChange(s.copy(humans = (s.humans - 1).coerceAtLeast(1))) },
                        { onChange(s.copy(humans = (s.humans + 1).coerceAtMost(s.players))) })
                    Stepper("Раундов", s.rounds,
                        { onChange(s.copy(rounds = (s.rounds - 5).coerceAtLeast(5))) },
                        { onChange(s.copy(rounds = (s.rounds + 5).coerceAtMost(40))) })
                    Text("Остальные игроки — боты. Люди играют по очереди на одном телефоне.", fontSize = 13.sp, color = Color.DarkGray)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onBack, Modifier.fillMaxWidth()) { Text("Готово") }
                }
            }
        }
    }
}
