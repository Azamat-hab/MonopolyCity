package com.example.minimonopoly

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        setContent { MaterialTheme { App() } }
        hideBars()
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }
}

data class GameSettings(
    val players: Int = 3,
    val humans: Int = 1,
    val rounds: Int = 15,
    val name: String = "Игрок 1"
)

enum class Screen { MENU, LOBBY, GAME }

@SuppressLint("MissingPermission")
@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("mm", Context.MODE_PRIVATE) }
    val uid = remember {
        prefs.getString("uid", null)
            ?: UUID.randomUUID().toString().take(8).also { prefs.edit().putString("uid", it).apply() }
    }
    var settings by remember {
        mutableStateOf(GameSettings(name = prefs.getString("name", "Игрок 1") ?: "Игрок 1"))
    }
    var screen by remember { mutableStateOf(Screen.MENU) }
    var game by remember { mutableStateOf<Game?>(null) }
    var transport by remember { mutableStateOf<Transport?>(null) }
    var lobbyNames by remember { mutableStateOf(listOf<String>()) }
    var lobbyId by remember { mutableIntStateOf(-1) }
    var lobbyTitle by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var tutorial by remember { mutableStateOf(!prefs.getBoolean("tut", false)) }
    var roomName by remember { mutableStateOf("") }
    var avatar by remember { mutableIntStateOf(prefs.getInt("av", 0)) }
    var friends by remember {
        mutableStateOf((prefs.getString("friends", "") ?: "").split("|").filter { it.isNotBlank() })
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    fun rememberFriends(names: List<String>) {
        val n = (names.filter { it != settings.name && it.isNotBlank() } + friends).distinct().take(20)
        if (n != friends) {
            friends = n
            prefs.edit().putString("friends", n.joinToString("|")).apply()
        }
    }

    fun leave() {
        transport?.close()
        transport = null
        game = null
        screen = Screen.MENU
    }

    fun attach(t: Transport, title: String) {
        transport = t
        lobbyTitle = title
        lobbyNames = emptyList()
        lobbyId = -1
        game = null
        t.onLobby = { names, id -> lobbyNames = names; lobbyId = id; rememberFriends(names) }
        t.onState = { s ->
            val g = game
            if (g == null) {
                val ng = Game.fromJson(s, lobbyId)
                ng.transport = t
                game = ng
                screen = Screen.GAME
            } else g.loadJson(s)
        }
        t.onAction = { a, by -> game?.act(Act.parse(a), by) }
        t.onError = { msg -> toast(msg) }
        screen = Screen.LOBBY
    }

    fun startLocal() {
        val ps = (0 until settings.players).map { i ->
            val bot = i >= settings.humans
            val name = when {
                i == 0 -> settings.name
                bot -> "Бот ${i - settings.humans + 1}"
                else -> "Игрок ${i + 1}"
            }
            Player(i, name, i, bot)
        }
        game = Game(ps, settings.rounds, Random.nextInt(MAPS.size), -1, false)
        screen = Screen.GAME
    }

    fun startHosted(bots: Int, rounds: Int) {
        val humans = lobbyNames.size
        val ps = lobbyNames.mapIndexed { i, n -> Player(i, n, i, false) } +
                (0 until bots).map { b -> Player(humans + b, "Бот ${b + 1}", humans + b, true) }
        val g = Game(ps, rounds, Random.nextInt(MAPS.size), 0, false)
        g.transport = transport
        game = g
        screen = Screen.GAME
        transport?.startGame(g.toJson())
    }

    fun createOnline() {
        val title = roomName.ifBlank { "Комната ${settings.name}" }
        val code = Online.create(title, uid, settings.name)
        attach(FirebaseNet(code, true, uid), "$title  [$code]")
    }

    fun joinOnline(r: Online.Room) {
        Online.join(r.code, uid, settings.name.replace("|", " ")) { ok, err ->
            if (ok) attach(FirebaseNet(r.code, false, uid), "${r.name}  [${r.code}]")
            else toast(err ?: "Не удалось войти")
        }
    }

    fun btAdapter(): BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    val btPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) dialog = "bt" else toast("Без разрешения Bluetooth играть нельзя")
    }

    BackHandler(enabled = screen != Screen.MENU) {
        if (screen == Screen.LOBBY) leave()
    }

    when (screen) {
        Screen.MENU -> MenuScreen(
            hasFirebase = Online.available(ctx),
            onPlay = { startLocal() },
            onProfile = { dialog = "profile" },
            onFriends = { dialog = "friends" },
            onSettings = { dialog = "settings" },
            onTutorial = { tutorial = true },
            onCreate = { roomName = ""; dialog = "create" },
            onJoin = { joinOnline(it) },
            onBluetooth = {
                if (Build.VERSION.SDK_INT >= 31 &&
                    ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) btPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
                else dialog = "bt"
            }
        )
        Screen.LOBBY -> LobbyScreen(
            title = lobbyTitle, names = lobbyNames, isHost = transport?.isHost == true,
            defaultRounds = settings.rounds,
            onStart = { bots, rounds -> startHosted(bots, rounds) },
            onLeave = { leave() }
        )
        Screen.GAME -> game?.let { GameScreen(it) { leave() } }
    }

    // ----- диалоги главного экрана -----
    when (dialog) {
        "profile" -> ProfileWindow(settings.name, avatar, onSave = { n, a ->
            settings = settings.copy(name = n)
            avatar = a
            prefs.edit().putString("name", n).putInt("av", a).apply()
            dialog = null
        }, onClose = { dialog = null })
        "friends" -> FriendsWindow(friends) { dialog = null }
        "settings" -> SettingsWindow(settings, { settings = it }) { dialog = null }
        "create" -> AlertDialog(
            onDismissRequest = { dialog = null },
            containerColor = CREAM, titleContentColor = INK, textContentColor = INK,
            title = { Text("Новый сервер") },
            text = {
                OutlinedTextField(
                    value = roomName, onValueChange = { roomName = it.take(20) },
                    label = { Text("Название комнаты") }, singleLine = true
                )
            },
            confirmButton = { Button(onClick = { dialog = null; createOnline() }) { Text("Создать") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Отмена") } }
        )
        "bt" -> {
            val adapter = btAdapter()
            CreamDialog("Bluetooth", onClose = { dialog = null }) {
                if (adapter == null) Text("На этом устройстве нет Bluetooth.")
                else if (!adapter.isEnabled) Text("Включите Bluetooth и откройте окно снова.")
                else {
                    Text(
                        "1) Сначала свяжите телефоны в настройках Bluetooth Android (сопряжение).\n" +
                                "2) Один создаёт игру, остальные подключаются к нему из списка.",
                        fontSize = 12.sp
                    )
                    Button(onClick = {
                        dialog = null
                        val t = BtNet(adapter, true, settings.name)
                        attach(t, "Bluetooth: ваша игра")
                        t.startHost()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Создать игру (я хост)") }
                    Text("Подключиться к:", fontWeight = FontWeight.Bold)
                    val devices = adapter.bondedDevices.toList()
                    if (devices.isEmpty()) Text("Нет сопряжённых устройств.", fontSize = 12.sp)
                    devices.forEach { d ->
                        OutlinedButton(onClick = {
                            dialog = null
                            val t = BtNet(adapter, false, settings.name)
                            attach(t, "Bluetooth: ${d.name}")
                            t.connect(d)
                        }, modifier = Modifier.fillMaxWidth()) { Text(d.name ?: d.address) }
                    }
                }
            }
        }
    }

    if (tutorial) {
        TutorialDialog {
            tutorial = false
            prefs.edit().putBoolean("tut", true).apply()
        }
    }
}

@Composable
fun MenuScreen(
    hasFirebase: Boolean,
    onPlay: () -> Unit, onProfile: () -> Unit, onFriends: () -> Unit, onSettings: () -> Unit,
    onTutorial: () -> Unit, onCreate: () -> Unit, onJoin: (Online.Room) -> Unit, onBluetooth: () -> Unit
) {
    var rooms by remember { mutableStateOf(listOf<Online.Room>()) }
    var error by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current
    DisposableEffect(hasFirebase) {
        val reg = if (hasFirebase) Online.listen({ rooms = it; error = null }, { error = it }) else null
        onDispose { reg?.remove() }
    }
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.bg_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        BoxWithConstraints(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            contentAlignment = Alignment.Center
        ) {
            // всё рисуется на «холсте» 1870x841 как на референсе
            val s = minOf(maxWidth / 1870, maxHeight / 841)
            Box(Modifier.size(s * 1870, s * 841)) {
                Area(s, 440, 15, 1425, 275) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "МИНИ-", color = Color.White, fontSize = (s.value * 92).sp,
                            fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic,
                            style = TextStyle(shadow = Shadow(Color(0xFF1B2A6B), Offset(3f, 6f), 8f))
                        )
                        Text(
                            "МОНОПОЛИЯ", color = Color(0xFFFFC21A), fontSize = (s.value * 128).sp,
                            fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic,
                            style = TextStyle(shadow = Shadow(Color(0xFF7A3B00), Offset(4f, 8f), 10f))
                        )
                    }
                }
                Area(s, 335, 295, 925, 470, onPlay) {
                    Image(painterResource(R.drawable.btn_play), "Играть", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                }
                Area(s, 300, 500, 510, 675, onProfile) {
                    Image(painterResource(R.drawable.btn_profile), "Профиль", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
                Area(s, 525, 500, 740, 675, onFriends) {
                    Image(painterResource(R.drawable.btn_friends), "Друзья", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
                Area(s, 755, 500, 965, 675, onSettings) {
                    Image(painterResource(R.drawable.btn_settings), "Настройки", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
                Area(s, 40, 730, 385, 815, onTutorial) {
                    Image(painterResource(R.drawable.btn_training), "Обучение", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                }
                // панель серверов
                Area(s, 1022, 290, 1637, 685) {
                    Image(painterResource(R.drawable.panel_servers), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                }
                Area(s, 1055, 375, 1320, 465, if (hasFirebase) onCreate else null) {
                    Image(painterResource(R.drawable.btn_create), "Создать сервер", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                    if (!hasFirebase) Dim(24.dp)
                }
                Area(s, 1340, 375, 1605, 465, onBluetooth) {
                    Image(painterResource(R.drawable.btn_bluetooth), "Bluetooth", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                }
                Area(s, 1045, 480, 1615, 602, align = Alignment.TopCenter) {
                    if (!hasFirebase) {
                        Text(
                            "Онлайн не настроен: добавьте google-services.json (инструкция в README).",
                            color = Color(0xFFFFCC80), fontSize = (s.value * 26).sp, textAlign = TextAlign.Center
                        )
                    } else if (rooms.isEmpty()) {
                        Text(
                            error?.let { "Ошибка: $it" } ?: "Открытых комнат нет. Создайте свою!",
                            color = Color(0xFFB0BEC5), fontSize = (s.value * 26).sp, textAlign = TextAlign.Center
                        )
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(s * 6),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            items(rooms) { r ->
                                val rs = s * (460f / 1612f)
                                Box(Modifier.size(rs * 1612, rs * 382).clickable { onJoin(r) }) {
                                    Image(painterResource(R.drawable.row_server), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                                    Area(rs, 400, 60, 1140, 300, align = Alignment.CenterStart) {
                                        Column {
                                            Text(r.name, fontSize = (rs.value * 80).sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                                            Text("Хост: ${r.host}", fontSize = (rs.value * 54).sp, color = Color(0xFFB0BEC5), maxLines = 1)
                                        }
                                    }
                                    Area(rs, 1155, 70, 1545, 210) {
                                        Text("${r.count}/4", fontSize = (rs.value * 90).sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
                Area(s, 1035, 608, 1625, 665) {
                    Box(
                        Modifier.fillMaxSize().background(Color(0x66081A55), RoundedCornerShape(24.dp)),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            "  i   Игра с ботами, вдвоём на одном телефоне и по Bluetooth работает без сервера.",
                            color = Color(0xFFD0DCF5), fontSize = (s.value * 21).sp, maxLines = 2
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LobbyScreen(
    title: String, names: List<String>, isHost: Boolean, defaultRounds: Int,
    onStart: (Int, Int) -> Unit, onLeave: () -> Unit
) {
    var bots by remember { mutableIntStateOf(0) }
    var rounds by remember { mutableIntStateOf(defaultRounds) }
    val humans = names.size
    val minBots = maxOf(0, 2 - humans)
    val maxBots = maxOf(0, 4 - humans)
    val b = bots.coerceIn(minBots, maxBots)
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.bg_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(16.dp), color = CREAM, modifier = Modifier.widthIn(max = 460.dp)) {
                Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = INK)
                    Text("Игроки (${names.size}/4):", color = INK)
                    names.forEachIndexed { i, n -> Text("${i + 1}. $n${if (i == 0) " (хост)" else ""}", color = INK, fontWeight = FontWeight.Bold) }
                    if (isHost) {
                        Text("Ботов: $b", color = INK)
                        if (maxBots > minBots) {
                            Slider(value = b.toFloat(), onValueChange = { bots = it.toInt() }, valueRange = minBots.toFloat()..maxBots.toFloat(), steps = maxBots - minBots - 1)
                        }
                        Text("Раундов: $rounds", color = INK)
                        Slider(value = rounds.toFloat(), onValueChange = { rounds = (it / 5).toInt() * 5 }, valueRange = 5f..40f, steps = 6)
                        Button(onClick = { onStart(b, rounds) }, enabled = humans + b >= 2, modifier = Modifier.fillMaxWidth()) { Text("Старт") }
                    } else {
                        Text("Ждём, пока хост запустит игру…", color = INK)
                    }
                    OutlinedButton(onClick = onLeave, modifier = Modifier.fillMaxWidth()) { Text("Выйти") }
                }
            }
        }
    }
}
