package com.example.minimonopoly

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.max

@Composable
fun GameScreen(game: Game, onExit: () -> Unit) {
    var spot by remember { mutableStateOf<Int?>(null) }
    var dlg by remember { mutableStateOf<String?>(null) }

    // Ходы ботов (считает только хост / локальная игра)
    LaunchedEffect(game.turn, game.round, game.finished) {
        if (!game.remote && !game.finished && game.current.isBot) {
            delay(1000); game.botBuild()
            delay(700); game.botLot()
            while (game.auction != null) delay(300)
            delay(800); game.act(Act("end"), game.current.id)
        }
    }
    val a = game.auction
    val bidder = a?.current
    LaunchedEffect(a, bidder, a?.price) {
        if (!game.remote && a != null && bidder != null && bidder.isBot) {
            delay(800); game.botBid()
        }
    }

    if (game.finished) {
        ResultsScreen(game, onExit)
        return
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF16213A))) {
        MapView(game, Modifier.fillMaxSize()) { spot = it }
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Hud(game, Modifier.align(Alignment.TopStart).padding(4.dp))
            SidePanel(
                game, { dlg = "market" }, { dlg = "factory" }, { dlg = "staff" }, { dlg = "exit" },
                Modifier.align(Alignment.CenterEnd).padding(4.dp)
            )
            BottomBar(
                game, { dlg = "lot" }, { dlg = "rating" },
                Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp)
            )
        }
    }

    // ----- диалоги -----
    val msg = game.message
    if (msg != null && (game.myId < 0 || game.messageFor == game.myId)) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = CREAM, titleContentColor = INK, textContentColor = INK,
            title = { Text(if (game.myId < 0) "Передайте телефон: ${game.current.name}" else "Ваш ход") },
            text = { Text(msg) },
            confirmButton = { Button(onClick = { game.act(Act("ack")) }) { Text("Начать ход") } }
        )
    } else if (game.auction != null && (game.message == null)) {
        game.auction?.let { AuctionDialog(game, it) }
    }
    spot?.let { s ->
        val b = game.buildings[s]
        if (b == null) SpotWindow(game, s) { spot = null } else InfoDialog(game, b) { spot = null }
    }
    when (dlg) {
        "lot" -> LotDialog(game) { dlg = null }
        "factory" -> FactoryDialog(game) { dlg = null }
        "staff" -> StaffDialog(game) { dlg = null }
        "market" -> MarketDialog(game) { dlg = null }
        "rating" -> RatingWindow(game) { dlg = null }
        "exit" -> AlertDialog(
            onDismissRequest = { dlg = null },
            containerColor = CREAM, titleContentColor = INK, textContentColor = INK,
            title = { Text("Выйти из игры?") },
            text = { Text("Прогресс этой партии будет потерян.") },
            confirmButton = { Button(onClick = { dlg = null; onExit() }) { Text("Выйти") } },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Остаться") } }
        )
    }
}

// ---------------- HUD (текстуры из Panel.png) ----------------
@Composable
fun Hud(game: Game, modifier: Modifier = Modifier) {
    val cur = game.viewer
    val h = 64.dp
    val s = h / 270f
    Box(modifier.size(s * 1172, h)) {
        Image(painterResource(R.drawable.hud_top), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        Area(s, 310, 40, 650, 120, align = Alignment.CenterStart) {
            Text("${fmt(cur.money)} \$", fontSize = (s.value * 56).sp, fontWeight = FontWeight.Bold, color = INK, maxLines = 1)
        }
        Area(s, 972, 45, 1145, 110, align = Alignment.CenterStart) {
            Text("${game.round}/${game.totalRounds}", fontSize = (s.value * 56).sp, fontWeight = FontWeight.Bold, color = INK, maxLines = 1)
        }
        val five = listOf(165 to Cat.FOOD, 368 to Cat.JEWELRY, 568 to Cat.SERVICES, 782 to Cat.CARS, 1000 to Cat.TECH)
        five.forEach { (x, c) ->
            val t = game.trend.getValue(c)
            val col = if (t > 0) Color(0xFF2E7D32) else if (t < 0) Color(0xFFC62828) else INK
            val arrow = if (t > 0) "▲" else if (t < 0) "▼" else ""
            Area(s, x, 165, x + 150, 235, align = Alignment.CenterStart) {
                Text("${game.prices.getValue(c)}$arrow", fontSize = (s.value * 46).sp, fontWeight = FontWeight.Bold, color = col, maxLines = 1)
            }
        }
    }
}

@Composable
fun BottomBar(game: Game, onLot: () -> Unit, onRating: () -> Unit, modifier: Modifier = Modifier) {
    val h = 58.dp
    val s = h / 285f
    val ok = game.canAct
    Box(modifier.size(s * 1205, h)) {
        Image(painterResource(R.drawable.hud_bottom), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        val canLot = ok && !game.lotPlaced
        Area(s, 40, 40, 395, 215, if (canLot) onLot else null) { if (!canLot) Dim(30.dp) }
        Area(s, 407, 40, 783, 215, onRating)
        Area(s, 795, 40, 1165, 215, if (ok) ({ game.act(Act("end")) }) else null) { if (!ok) Dim(30.dp) }
    }
}

@Composable
fun PanelButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(28.dp).alpha(if (enabled) 1f else 0.45f)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.btn_panel), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun SidePanel(
    game: Game, onMarket: () -> Unit, onFactory: () -> Unit, onStaff: () -> Unit, onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val h = 196.dp
    val w = h * 370f / 665f
    val cur = game.current
    Box(modifier.size(w, h)) {
        Image(painterResource(R.drawable.hud_side), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        Column(
            Modifier.fillMaxSize().padding(horizontal = 9.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(cur.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
            Text(if (game.mine) "доход ${signed(game.income)}" else "ходит…", color = Color(0xFFB3E5FC), fontSize = 10.sp, maxLines = 1)
            Text("слотов: ${game.freeSlots(game.viewer)}", color = Color(0xFFFFE082), fontSize = 10.sp, maxLines = 1)
            Spacer(Modifier.weight(1f))
            PanelButton("Рынок", true, onMarket)
            PanelButton("Завод", game.canAct, onFactory)
            PanelButton("Персонал", game.canAct, onStaff)
            PanelButton("Выход", true, onExit)
        }
    }
}

// ---------------- Карта с «стенами» ----------------
@Composable
fun MapView(game: Game, modifier: Modifier, onSpot: (Int) -> Unit) {
    val def = MAPS[game.mapIdx]
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    BoxWithConstraints(modifier.clipToBounds().background(Color(0xFF16213A))) {
        val vw = constraints.maxWidth.toFloat()
        val vh = constraints.maxHeight.toFloat()
        val density = LocalDensity.current
        val fitW = vw / vh > def.aspect
        val mapWpx = if (fitW) vw else vh * def.aspect   // карта всегда полностью закрывает экран
        val mapHpx = if (fitW) vw / def.aspect else vh
        val mapW = with(density) { mapWpx.toDp() }
        val mapH = with(density) { mapHpx.toDp() }

        fun clampOffset(o: Offset, sc: Float): Offset {
            val mx = max(0f, (mapWpx * sc - vw) / 2f)
            val my = max(0f, (mapHpx * sc - vh) / 2f)
            return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
        }

        Box(
            Modifier.fillMaxSize().pointerInput(vw, vh) {
                detectTransformGestures { centroid, pan, zoom, _ ->
                    val ns = (scale * zoom).coerceIn(1f, 4f)
                    val z = ns / scale
                    val pc = centroid - Offset(vw / 2f, vh / 2f)
                    offset = clampOffset(pc - (pc - offset) * z + pan, ns)
                    scale = ns
                }
            }
        ) {
            Box(
                Modifier.requiredSize(mapW, mapH).align(Alignment.Center).graphicsLayer {
                    scaleX = scale; scaleY = scale
                    translationX = offset.x; translationY = offset.y
                }
            ) {
                Image(painterResource(def.res), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                def.spots.forEachIndexed { i, (fx, fy) ->
                    val b = game.buildings[i]
                    val size = if (b == null) 30.dp else 44.dp
                    Box(
                        Modifier.offset(mapW * fx - size / 2, mapH * fy - size / 2).size(size)
                            .clickable { onSpot(i) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (b != null) {
                            Image(painterResource(b.type.res), null, Modifier.fillMaxSize())
                            Box(
                                Modifier.align(Alignment.BottomCenter).size(12.dp)
                                    .background(b.owner.color, CircleShape)
                                    .border(1.5.dp, Color.White, CircleShape)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------- Диалоги ----------------
@Composable
fun CatChips(selected: Cat, game: Game, onSelect: (Cat) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Cat.entries.forEach { c ->
            FilterChip(
                selected = selected == c, onClick = { onSelect(c) },
                label = { Text("${c.title} ${game.prices.getValue(c)}\$", fontSize = 12.sp) },
                leadingIcon = { Box(Modifier.size(10.dp).background(Color(c.color), CircleShape)) }
            )
        }
    }
}

@Composable
fun LotDialog(game: Game, onClose: () -> Unit) {
    var cat by remember { mutableStateOf(Cat.FOOD) }
    var qty by remember { mutableFloatStateOf(20f) }
    var pct by remember { mutableFloatStateOf(80f) }
    val q = qty.toInt()
    val market = q * game.prices.getValue(cat)
    val start = max(1, (market * pct / 100f).toInt())
    val me = game.viewer
    CreamDialog(
        "Выставить товар", onClose,
        confirm = {
            Button(
                onClick = { game.act(Act("lot", q, start, cat.name)); onClose() },
                enabled = me.money >= start && game.canAct && !game.lotPlaced
            ) { Text("Выставить") }
        }
    ) {
        CatChips(cat, game) { cat = it }
        Text("Количество: $q")
        Slider(value = qty, onValueChange = { qty = it }, valueRange = 1f..120f)
        Text("Стартовая цена: ${pct.toInt()}% от рынка")
        Slider(value = pct, onValueChange = { pct = it }, valueRange = 30f..150f)
        Text("Рыночная стоимость: ${fmt(market)} \$")
        Text("Старт аукциона: ${fmt(start)} \$", fontWeight = FontWeight.Bold)
        Text(
            "Свободных слотов: ${game.freeSlots(me)}. Если никто не поставит ставку, вы выкупите лот сами по стартовой цене.",
            fontSize = 12.sp, color = Color.DarkGray
        )
        if (me.money < start) Text("Не хватает денег на выкуп", color = Color.Red, fontSize = 12.sp)
    }
}

@Composable
fun FactoryDialog(game: Game, onClose: () -> Unit) {
    var cat by remember { mutableStateOf(Cat.CLOTHES) }
    var qty by remember { mutableFloatStateOf(20f) }
    var pricePct by remember { mutableFloatStateOf(130f) }
    val q = qty.toInt()
    val market = game.prices.getValue(cat)
    val price = max(1, (market * pricePct / 100f).toInt())
    val cost = game.factoryCost(cat, q)
    val normal = market * Config.RETAIL_MARKUP
    val demand = (2.0 - price / normal).coerceIn(0.2, 1.4)
    val me = game.viewer
    CreamDialog(
        "Завод: свой товар", onClose,
        confirm = {
            Button(
                onClick = { game.act(Act("factory", q, price, cat.name)); onClose() },
                enabled = game.canAct && !game.factoryUsed && me.money >= cost
            ) { Text("Заказать") }
        }
    ) {
        Text("Завод делает товар вашей марки дешевле рынка. Вы выбираете категорию и цену продажи: чем выше цена, тем медленнее раскупают.", fontSize = 12.sp)
        CatChips(cat, game) { cat = it }
        Text("Количество: $q (макс. ${Config.FACTORY_MAX_QTY})")
        Slider(value = qty, onValueChange = { qty = it }, valueRange = 1f..Config.FACTORY_MAX_QTY.toFloat())
        Text("Ваша цена за штуку: $price \$ (${pricePct.toInt()}% от рынка)")
        Slider(value = pricePct, onValueChange = { pricePct = it }, valueRange = 60f..220f)
        Text("Цена завода: ${fmt(cost)} \$", fontWeight = FontWeight.Bold)
        Text("Скорость продаж: ×${"%.1f".format(demand)} от обычной", fontSize = 12.sp)
        if (game.factoryUsed) Text("В этом ходу завод уже работал", color = Color.Red, fontSize = 12.sp)
        else if (me.money < cost) Text("Не хватает денег", color = Color.Red, fontSize = 12.sp)
    }
}

@Composable
fun StaffDialog(game: Game, onClose: () -> Unit) {
    val me = game.viewer
    CreamDialog("Персонал", onClose) {
        Text("Консультант — ${fmt(Config.CONSULTANT_COST)} \$", fontWeight = FontWeight.Bold)
        Text("+10% к розничной наценке: вся ваша выручка с товара растёт.", fontSize = 12.sp)
        Button(
            onClick = { game.act(Act("hire", s = "cons")) },
            enabled = game.canAct && !me.consultant && me.money >= Config.CONSULTANT_COST
        ) { Text(if (me.consultant) "Нанят" else "Нанять") }
        Spacer(Modifier.height(6.dp))
        Text("Бухгалтер — ${fmt(Config.ACCOUNTANT_COST)} \$", fontWeight = FontWeight.Bold)
        Text("Аренда лавок вдвое меньше, шанс пожара и ограбления 5% вместо 10%.", fontSize = 12.sp)
        Button(
            onClick = { game.act(Act("hire", s = "acc")) },
            enabled = game.canAct && !me.accountant && me.money >= Config.ACCOUNTANT_COST
        ) { Text(if (me.accountant) "Нанят" else "Нанять") }
    }
}

@Composable
fun MarketDialog(game: Game, onClose: () -> Unit) {
    val me = game.viewer
    val shelf = HashMap<Cat, Int>()
    game.buildings.values.filter { it.owner === me }.forEach { b ->
        b.stock.forEach { (i, n) -> shelf[i.cat] = (shelf[i.cat] ?: 0) + n }
    }
    CreamDialog("Рынок и склад", onClose) {
        Text("Цена за штуку · на складе · на полках", fontSize = 12.sp, color = Color.DarkGray)
        Cat.entries.forEach { c ->
            val t = game.trend.getValue(c)
            val arrow = if (t > 0) "▲" else if (t < 0) "▼" else "•"
            val col = if (t > 0) Color(0xFF2E7D32) else if (t < 0) Color(0xFFC62828) else INK
            val wh = me.warehouse.filterKeys { it.cat == c }.values.sum()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(Color(c.color), CircleShape))
                Text(" ${c.title}", Modifier.weight(1f), fontSize = 14.sp)
                Text("${game.prices.getValue(c)}\$ $arrow", color = col, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("  $wh · ${shelf[c] ?: 0}", fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun InfoDialog(game: Game, b: Building, onClose: () -> Unit) {
    val own = game.canAct && b.owner === game.viewer && b.type.slots > 0
    val inc = game.expectedIncome(b)
    CreamDialog("${b.type.title} · ${b.owner.name}", onClose) {
        if (b.type.flatIncome > 0) Text("Доход ${fmt(b.type.flatIncome)} за ход")
        else {
            Text("Занято слотов: ${b.used}/${b.type.slots}")
            if (b.stock.isEmpty()) Text("Полки пусты: выложите товар со склада.", color = Color(0xFFC62828), fontSize = 12.sp)
            b.stock.forEach { (i, n) -> Text("${i.label}: $n") }
        }
        Text("Ожидаемый доход за ход: ${signed(inc)} \$", fontWeight = FontWeight.Bold)
        if (own) {
            Text("Выложить со склада:", fontWeight = FontWeight.Bold)
            if (b.owner.warehouse.isEmpty()) Text("На складе пусто. Купите товар на аукционе или закажите на заводе.", fontSize = 12.sp)
            b.owner.warehouse.entries.toList().forEach { (item, n) ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${item.label}: $n", Modifier.weight(1f), fontSize = 13.sp)
                    Button(
                        onClick = { game.act(Act("stock", b.spot, 10, item.key)) },
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text("+10", fontSize = 12.sp) }
                    Button(
                        onClick = { game.act(Act("stock", b.spot, n, item.key)) },
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) { Text("Все", fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
fun AuctionDialog(game: Game, a: Auction) {
    val bidder = a.current
    val mine = bidder != null && !bidder.isBot && (game.myId < 0 || bidder.id == game.myId)
    AlertDialog(
        onDismissRequest = {},
        containerColor = CREAM, titleContentColor = INK, textContentColor = INK,
        title = { Text("Аукцион: ${a.item.cat.title} ×${a.qty}", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Продавец: ${a.seller.name}")
                Text("Рыночная стоимость лота: ${fmt(a.qty * game.prices.getValue(a.item.cat))} \$")
                Text("Цена: ${fmt(a.price)} \$   Лидер: ${a.leader?.name ?: "—"}", fontWeight = FontWeight.Bold)
                if (bidder != null) {
                    Text("Ставит: ${bidder.name}${if (bidder.isBot) " (бот)" else ""}", color = bidder.color, fontWeight = FontWeight.Bold)
                    if (mine && bidder != null) {
                        val mb = game.minBid(a)
                        val opts = listOf(mb, (mb * 1.1).toInt(), (mb * 1.25).toInt()).distinct().filter { it <= bidder.money }
                        Text("Ваши деньги: ${fmt(bidder.money)} \$", fontSize = 12.sp, color = Color.DarkGray)
                        opts.forEach { amount ->
                            Button(onClick = { game.act(Act("bid", amount)) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Ставка ${fmt(amount)} \$")
                            }
                        }
                        OutlinedButton(onClick = { game.act(Act("pass")) }, modifier = Modifier.fillMaxWidth()) { Text("Пас") }
                    }
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
fun ScoreList(game: Game) {
    val sorted = game.players.sortedByDescending { game.netWorth(it) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        sorted.forEachIndexed { i, p ->
            val w = game.netWorth(p)
            val diff = w - Config.START_MONEY
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}. ", fontWeight = FontWeight.Bold, color = INK)
                Box(Modifier.size(12.dp).background(p.color, CircleShape))
                Text(" ${p.name}", Modifier.weight(1f), color = INK)
                Text("${fmt(w)} \$  ", fontWeight = FontWeight.Bold, color = INK)
                Text(signed(diff), color = if (diff >= 0) Color(0xFF2E7D32) else Color(0xFFC62828))
            }
        }
    }
}

@Composable
fun ResultsScreen(game: Game, onExit: () -> Unit) {
    val winner = game.players.maxByOrNull { game.netWorth(it) }
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.bg_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxSize().padding(24.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = MaterialTheme.shapes.large, color = Color.White, modifier = Modifier.widthIn(max = 460.dp)) {
                Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.money_scatter), null, Modifier.size(70.dp))
                    Text("Победил: ${winner?.name ?: ""}", fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = INK)
                    Spacer(Modifier.height(8.dp))
                    ScoreList(game)
                    Text("Счёт = деньги + товар по рыночной цене + 50% стоимости зданий", fontSize = 11.sp, color = Color.Gray)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("В меню") }
                }
            }
        }
    }
}
