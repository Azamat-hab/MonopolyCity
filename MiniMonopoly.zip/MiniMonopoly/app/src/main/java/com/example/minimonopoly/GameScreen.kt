package com.example.minimonopoly

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.paint
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val INK = Color(0xFF1B2A41)

@Composable
fun GameScreen(game: Game, onExit: () -> Unit) {
    var spot by remember { mutableStateOf<Int?>(null) }
    var showLot by remember { mutableStateOf(false) }
    var showScores by remember { mutableStateOf(false) }

    // Ход бота
    LaunchedEffect(game.turn, game.round) {
        if (!game.finished && game.current.isBot) {
            delay(1000)
            game.botBuild()
            delay(700)
            game.botLot()
            while (game.auction != null) delay(300)
            delay(800)
            game.endTurn()
        }
    }
    // Ставки ботов
    val a = game.auction
    val bidder = a?.current
    LaunchedEffect(a, bidder, a?.price) {
        if (a != null && bidder != null && bidder.isBot) {
            delay(800)
            game.botBid()
        }
    }

    if (game.finished) {
        ResultsScreen(game, onExit)
        return
    }

    val cur = game.current
    val humanTurn = !cur.isBot && game.auction == null && game.message == null

    Column(Modifier.fillMaxSize().background(Color(0xFF16213A))) {
        Hud(game)
        MapView(game, Modifier.weight(1f).fillMaxWidth()) { spot = it }
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Text(
                game.log.takeLast(2).joinToString("\n").ifEmpty { " " },
                color = Color.White, fontSize = 12.sp, maxLines = 2
            )
            Spacer(Modifier.height(6.dp))
            if (cur.isBot) {
                Text("Ходит ${cur.name}…", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { showLot = true },
                    enabled = humanTurn && !game.lotPlaced,
                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                ) { Text("Товар", fontSize = 13.sp) }
                OutlinedButton(
                    onClick = { showScores = true },
                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                ) { Text("Рейтинг", fontSize = 13.sp, color = Color.White) }
                Button(
                    onClick = { game.endTurn() },
                    enabled = humanTurn,
                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                ) { Text("Конец хода", fontSize = 13.sp) }
            }
            if (humanTurn) Text("Нажмите красную точку, чтобы построить", color = Color(0xFFB0BEC5), fontSize = 11.sp)
        }
    }

    game.message?.let { msg ->
        AlertDialog(
            onDismissRequest = {},
            confirmButton = { TextButton(onClick = { game.message = null }) { Text("Начать ход") } },
            title = { Text("Передайте телефон") },
            text = { Text(msg) }
        )
    }
    if (game.message == null) {
        game.auction?.let { AuctionDialog(game, it) }
    }
    spot?.let { s ->
        val b = game.buildings[s]
        if (b == null) BuildDialog(game, s, humanTurn) { spot = null }
        else InfoDialog(game, b) { spot = null }
    }
    if (showLot) LotDialog(game) { showLot = false }
    if (showScores) {
        AlertDialog(
            onDismissRequest = { showScores = false },
            confirmButton = { TextButton(onClick = { showScores = false }) { Text("Закрыть") } },
            title = { Text("Рейтинг") },
            text = { ScoreList(game) }
        )
    }
}

@Composable
fun Hud(game: Game) {
    val cur = game.current
    Box(
        Modifier.fillMaxWidth()
            .paint(painterResource(R.drawable.ui_frame), contentScale = ContentScale.FillBounds)
            .padding(horizontal = 22.dp, vertical = 14.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(14.dp).background(cur.color, CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(cur.name + if (cur.isBot) " 🤖" else "", fontWeight = FontWeight.Bold, color = INK)
                Spacer(Modifier.weight(1f))
                Text("Раунд ${game.round}/${game.totalRounds}", color = INK)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.ic_money), null, Modifier.size(24.dp))
                Spacer(Modifier.width(6.dp))
                Text("${fmt(cur.money)} $", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = INK)
                Spacer(Modifier.weight(1f))
                Text("Слотов свободно: ${game.freeSlots(cur)}", fontSize = 12.sp, color = INK)
            }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                Cat.entries.forEach { c ->
                    val t = game.trend.getValue(c)
                    val arrow = if (t > 0) "▲" else if (t < 0) "▼" else ""
                    val col = if (t > 0) Color(0xFF2E7D32) else if (t < 0) Color(0xFFC62828) else INK
                    Text("${c.icon}${game.prices.getValue(c)}$arrow  ", color = col, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun MapView(game: Game, modifier: Modifier, onSpot: (Int) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    BoxWithConstraints(
        modifier.clipToBounds().background(Color(0xFF2E5E2E))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    offset += pan
                }
            }
    ) {
        val mapH = maxHeight
        val mapW = mapH * 1.5f
        Box(
            Modifier.requiredSize(mapW, mapH).align(Alignment.Center).graphicsLayer {
                scaleX = scale; scaleY = scale
                translationX = offset.x; translationY = offset.y
            }
        ) {
            Image(painterResource(R.drawable.map_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
            SPOTS.forEachIndexed { i, (fx, fy) ->
                val b = game.buildings[i]
                val size = if (b == null) 28.dp else 56.dp
                Box(
                    Modifier.offset(mapW * fx - size / 2, mapH * fy - size / 2).size(size).clickable { onSpot(i) },
                    contentAlignment = Alignment.Center
                ) {
                    if (b == null) {
                        Box(Modifier.size(20.dp).background(Color.Red, CircleShape).border(2.dp, Color.White, CircleShape))
                    } else {
                        Image(painterResource(b.type.res), null, Modifier.fillMaxSize())
                        Box(
                            Modifier.align(Alignment.BottomCenter).size(13.dp)
                                .background(b.owner.color, CircleShape).border(1.5.dp, Color.White, CircleShape)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BuildDialog(game: Game, spot: Int, enabled: Boolean, onClose: () -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Закрыть") } },
        title = { Text("Свободная точка") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!enabled) Text("Строить можно только в свой ход.", color = Color.Gray)
                BType.entries.forEach { t ->
                    Button(
                        onClick = {
                            error = game.buyBuilding(spot, t)
                            if (error == null) onClose()
                        },
                        enabled = enabled && game.current.money >= t.cost,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${t.title} — ${fmt(t.cost)} $", fontWeight = FontWeight.Bold)
                            Text(t.description(), fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
                error?.let { Text(it, color = Color.Red) }
            }
        }
    )
}

@Composable
fun InfoDialog(game: Game, b: Building, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Закрыть") } },
        title = { Text("${b.type.title} · ${b.owner.name}") },
        text = {
            Column {
                Text(b.type.description())
                if (b.type.slots > 0) {
                    Spacer(Modifier.height(6.dp))
                    Text("Занято слотов: ${b.used}/${b.type.slots}")
                    b.stock.forEach { (c, n) -> Text("${c.icon} ${c.title}: $n") }
                }
                Spacer(Modifier.height(6.dp))
                Text("Ожидаемый доход за ход: ${signed(game.expectedIncome(b))} $", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun LotDialog(game: Game, onClose: () -> Unit) {
    var cat by remember { mutableStateOf(Cat.FOOD) }
    var qty by remember { mutableFloatStateOf(20f) }
    var pct by remember { mutableFloatStateOf(80f) }
    val q = qty.toInt()
    val market = q * game.prices.getValue(cat)
    val start = (market * pct / 100f).toInt()
    val me = game.current
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = {
            Button(onClick = { game.startAuction(cat, q, start); onClose() }, enabled = me.money >= start) {
                Text("Выставить")
            }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } },
        title = { Text("Выставить товар") },
        text = {
            Column {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Cat.entries.forEach { c ->
                        FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text("${c.icon} ${c.title}") })
                    }
                }
                Text("Количество: $q", Modifier.padding(top = 8.dp))
                Slider(value = qty, onValueChange = { qty = it }, valueRange = 1f..120f)
                Text("Стартовая цена: ${pct.toInt()}% от рынка")
                Slider(value = pct, onValueChange = { pct = it }, valueRange = 30f..150f)
                Text("Рыночная стоимость: ${fmt(market)} $")
                Text("Старт аукциона: ${fmt(start)} $", fontWeight = FontWeight.Bold)
                Text(
                    "Свободных слотов у вас: ${game.freeSlots(me)}. Если никто не поставит ставку, вы выкупите лот сами по стартовой цене.",
                    fontSize = 12.sp, color = Color.Gray
                )
                if (me.money < start) Text("Не хватает денег на выкуп", color = Color.Red, fontSize = 12.sp)
            }
        }
    )
}

@Composable
fun AuctionDialog(game: Game, a: Auction) {
    val bidder = a.current
    AlertDialog(
        onDismissRequest = {},
        confirmButton = {},
        title = { Text("Аукцион: ${a.cat.icon} ${a.cat.title} ×${a.qty}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Продавец: ${a.seller.name}")
                Text("Рыночная стоимость лота: ${fmt(a.qty * game.prices.getValue(a.cat))} $")
                Text("Цена: ${fmt(a.price)} $   Лидер: ${a.leader?.name ?: "—"}", fontWeight = FontWeight.Bold)
                if (bidder != null) {
                    Text("Ставит: ${bidder.name}${if (bidder.isBot) " 🤖" else ""}", color = bidder.color, fontWeight = FontWeight.Bold)
                    if (!bidder.isBot) {
                        val mb = game.minBid(a)
                        val options = listOf(mb, (mb * 1.1).toInt(), (mb * 1.25).toInt())
                            .distinct().filter { it <= bidder.money }
                        Text("Ваши деньги: ${fmt(bidder.money)} $", fontSize = 12.sp, color = Color.Gray)
                        options.forEach { amount ->
                            Button(onClick = { game.bid(amount) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Ставка ${fmt(amount)} $")
                            }
                        }
                        OutlinedButton(onClick = { game.pass() }, modifier = Modifier.fillMaxWidth()) { Text("Пас") }
                    }
                }
            }
        }
    )
}

@Composable
fun ScoreList(game: Game) {
    val sorted = game.players.sortedByDescending { game.netWorth(it) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        sorted.forEachIndexed { i, p ->
            val w = game.netWorth(p)
            val diff = w - Config.START_MONEY
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}. ", fontWeight = FontWeight.Bold)
                Box(Modifier.size(12.dp).background(p.color, CircleShape))
                Text(" ${p.name}", Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text("${fmt(w)} $", fontWeight = FontWeight.Bold)
                    Text(signed(diff), fontSize = 12.sp, color = if (diff >= 0) Color(0xFF2E7D32) else Color(0xFFC62828))
                }
            }
        }
        Text("Счёт = деньги + товар по рыночной цене + 50% стоимости зданий", fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
fun ResultsScreen(game: Game, onExit: () -> Unit) {
    val winner = game.players.maxByOrNull { game.netWorth(it) }
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.bg_city), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Surface(shape = MaterialTheme.shapes.large, color = Color.White) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(painterResource(R.drawable.money_scatter), null, Modifier.size(110.dp))
                    Text("🏆 Победил: ${winner?.name ?: ""}", fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    ScoreList(game)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onExit, Modifier.fillMaxWidth()) { Text("В меню") }
                }
            }
        }
    }
}
